# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

OpenDataArena (ODA) is a bilingual (Chinese/English) static website for AI model benchmarking. It displays LLM and multi-modal model leaderboards, dataset comparisons, and data lineage visualizations. Deployed to GitHub Pages via the `gh-pages` branch.

## Development

```bash
python server.py          # Local dev server at http://localhost:8008
./deploy.sh               # Deploy to GitHub Pages (force-pushes gh-pages)
```

No build step — HTML/CSS/JS are served directly. Vue 3, Chart.js, and D3.js are loaded from CDNs (no npm/package.json).

### Data update workflow

1. Update source Excel in `data/llm/` or `data/mm/`
2. Run `python data/llm/1_excel.py` → generates JSON for frontend
3. Optionally run `2_score.py` for score statistics, `3_merge.py` to consolidate
4. Commit the resulting JSON files

## Architecture

**Frontend:** Each HTML page has a corresponding Vue 3 app in `js/` and stylesheet in `css/`. Vue is used via global `<script>` tags (no SFC/build tooling).

**Key JS files:**
- `js/leaderboard.js` — Main leaderboard app (sorting, filtering, model family tabs, efficiency metrics)
- `js/data-lineage.js` — D3.js-based lineage graph visualization (~4500 lines)
- `js/data-comparison.js` — Dataset comparison with Chart.js
- `js/general.js` — Shared utilities: i18n plugin, feedback form, sticky header
- `js/lang.js` — All translation strings (`lang_index` per-page, `lang_all` global); i18n uses `$t()` injected by Vue plugin

**Data pipeline (Python, gitignored):**
- `data/llm/1_excel.py` — ETL from Excel to JSON. Column mappings in `ExcelProcessor.DEFAULT_COLUMN_CONFIG` (0-indexed), with per-sheet overrides via `SHEET_SPECIFIC_COLUMN_CONFIG`
- `data-lineage/website/api_server.py` — Flask API for lineage data; uses `OPENAI_API_KEY`/`OPENAI_BASE_URL`/`OPENAI_MODEL` env vars for LLM summaries

## Key Patterns

- **i18n:** Language stored in `localStorage.oda_lang`, detected from `navigator.language`. Translations in `js/lang.js`. Adding UI text requires entries in both `zhCN` and `en` objects.
- **Chart.js lifecycle:** Chart instances are stored in module-level variables, destroyed and recreated on data changes. Uses `nextTick()` + `setTimeout()` to wait for DOM readiness.
- **Leaderboard types:** LLM vs MM (multimodal) toggled via `leaderboardType` ref. Each has separate JSON data and model family definitions.
- **Python data files are gitignored:** `data/llm/*.py`, `*.xlsx`, `*.log`, and processing outputs are excluded from the repo. Only the final JSON files are committed.
- **Analytics:** Google Analytics is disabled on localhost, `file://`, or when DNT is set.
