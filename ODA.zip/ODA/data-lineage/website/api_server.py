#!/usr/bin/env python3
"""
Data Lineage Visualization API Server
Provides source data summarization functionality
"""

import os
import sys
import re
import json
import fcntl
import logging
import hashlib
import threading
import urllib.request
import urllib.error
from pathlib import Path
from contextlib import contextmanager
from datetime import datetime
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate

CURRENT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = CURRENT_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from data_lineage.frontend_bridge import (
    DatasetFormatError,
    DatasetNotFoundError,
    process_single_dataset,
)

# Configure logging to both console and file
log_file = os.path.join(os.path.dirname(__file__), 'api_server.log')
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_file, encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

app = Flask(__name__, static_folder='.', static_url_path='')
CORS(app)  # Enable CORS

# Global LLM instance
llm = None

# Cache file path
CACHE_FILE = os.path.join(os.path.dirname(__file__), 'summary_cache.json')
OUTPUT_ROOT = PROJECT_ROOT / 'output'
MODALITY_CONFIG = {
    'text': {
        'output_dir': OUTPUT_ROOT / 'text-only_modality',
        'enable_multimodal': False,
    },
    'multimodal': {
        'output_dir': OUTPUT_ROOT / 'multimodal',
        'enable_multimodal': True,
    },
}
LINEAGE_PROCESS_LOCK = threading.Lock()
DATASET_PATTERN = re.compile(r"^[^/\s]+/[^/\s]+$")

# Source data summarization prompt templates
SOURCE_SUMMARY_PROMPT_ZH = """你是一个数据专家，擅长分析数据集的组成特点。请根据以下信息，生成一份自然流畅的数据特点分析报告。

目标数据集信息：
名称：{target_name}
描述：{target_description}
类别：{target_categories}
类型：{target_data_type}

直接来源数据：共 {total_source_count} 个（其中 {traceable_count} 个在 Hugging Face 上可查）
{missing_hf_info}
可追溯的 Source Data 详情：
{source_list}
{benchmark_info}
报告需涵盖：
1. 目标数据集的定位与用途（结合其描述、类别和类型）
2. source data 的整体组成特点（领域覆盖、类型分布、如何支撑目标数据集等）；分析时可有目的性地提及 1-2 个具有代表性的数据集名称加以说明，但不要机械罗列所有名称
3. {traceability_instruction}
4. {benchmark_instruction}

要求：
- 报告总字数控制在 120-180 字
- 语言自然流畅，像一段分析文字而非填表
- 直接返回报告正文，不要包含任何格式标记、编号或引号"""

SOURCE_SUMMARY_PROMPT_EN = """You are a data expert skilled in analyzing dataset composition characteristics. Based on the following information, generate a natural and insightful data analysis report.

Target Dataset Information:
Name: {target_name}
Description: {target_description}
Categories: {target_categories}
Type: {target_data_type}

Direct source datasets: {total_source_count} total ({traceable_count} traceable on Hugging Face)
{missing_hf_info}
Traceable Source Data Details:
{source_list}
{benchmark_info}
The report should cover:
1. The positioning and purpose of the target dataset (based on its description, categories, and type)
2. The overall composition of source data (domain coverage, type distribution, how they support the target dataset); you may purposefully mention 1-2 representative dataset names to illustrate a point, but avoid mechanically listing all names
3. {traceability_instruction}
4. {benchmark_instruction}

Requirements:
- Keep the report between 80-120 words
- Write in a natural, analytical tone — like a paragraph of expert commentary, not a form
- Return only the report text directly, without any format markers, numbering, or quotes"""

def init_llm():
    """Initialize LLM"""
    global llm
    
    # Get API configuration from environment variables
    base_url = os.getenv('OPENAI_BASE_URL')
    api_key = os.getenv('OPENAI_API_KEY')
    model = os.getenv('OPENAI_MODEL', 'gpt-5-nano')
    
    if not api_key:
        logger.warning("OPENAI_API_KEY not set, LLM functionality will be disabled")
        return None
    
    if not base_url:
        logger.warning("OPENAI_BASE_URL not set, using default")
        base_url = 'https://api.boyuerichdata.opensphereai.com/v1'
    
    try:
        llm = ChatOpenAI(
            model=model,
            base_url=base_url,
            api_key=api_key,
            temperature=0.3,
            max_retries=5,
            request_timeout=30
        )
        logger.info(f"LLM initialized with model: {model}, base_url: {base_url}")
        return llm
    except Exception as e:
        logger.error(f"Failed to initialize LLM: {e}")
        return None

def get_cache_key(target_name, target_info, source_data_list, source_info_map, language='zh', benchmark_contamination=None):
    """Generate cache key based on target and source information, including language and benchmark contamination"""
    # Build data structure for hashing, ensuring all relevant information is included
    # Sort source_info_map to ensure consistency
    sorted_source_info = {}
    for key in sorted(source_info_map.keys()):
        info = source_info_map[key]
        sorted_source_info[key] = {
            'summary': info.get('summary', ''),
            'categories': sorted(info.get('categories', [])) if isinstance(info.get('categories'), list) else info.get('categories', ''),
            'data_type': info.get('data_type', '')
        }
    
    # Normalize benchmark contamination: sort paths list for deterministic hashing
    normalized_contamination = sorted(
        [tuple(p) for p in (benchmark_contamination or [])],
        key=lambda x: x[0] if x else ''
    )

    cache_data = {
        'target_name': target_name,
        'target_info': {
            'summary': target_info.get('summary', ''),
            'categories': sorted(target_info.get('categories', [])) if isinstance(target_info.get('categories'), list) else target_info.get('categories', ''),
            'data_type': target_info.get('data_type', '')
        },
        'source_data_list': sorted([s.get('name', '') for s in source_data_list]),
        'source_info_map': sorted_source_info,
        'language': language,
        'benchmark_contamination': [list(p) for p in normalized_contamination]
    }
    # Generate hash
    cache_str = json.dumps(cache_data, sort_keys=True, ensure_ascii=False)
    cache_key = hashlib.md5(cache_str.encode('utf-8')).hexdigest()
    return cache_key

def load_cache():
    """Load cache file"""
    if not os.path.exists(CACHE_FILE):
        return {}
    try:
        with open(CACHE_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        logger.warning(f"Failed to load cache: {e}")
        return {}

def save_cache(cache_key, target_name, summary):
    """Save result to cache"""
    cache = load_cache()
    cache[cache_key] = {
        'target_name': target_name,
        'summary': summary,
        'created_at': datetime.now().isoformat()
    }
    try:
        with open(CACHE_FILE, 'w', encoding='utf-8') as f:
            json.dump(cache, f, ensure_ascii=False, indent=2)
        logger.info(f"Cache saved for {target_name} (key: {cache_key[:8]}...)")
    except Exception as e:
        logger.error(f"Failed to save cache: {e}")

def get_from_cache(cache_key):
    """Get result from cache"""
    cache = load_cache()
    return cache.get(cache_key)


@contextmanager
def file_lock(lock_path):
    os.makedirs(os.path.dirname(lock_path), exist_ok=True)
    with open(lock_path, 'a+', encoding='utf-8') as lock_handle:
        fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(lock_handle.fileno(), fcntl.LOCK_UN)


def load_graph_data(graph_file):
    graph_data = []
    if not os.path.exists(graph_file):
        return graph_data
    with open(graph_file, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                graph_data.append(json.loads(line))
            except json.JSONDecodeError:
                logger.warning("Skipped invalid graph jsonl line")
    return graph_data


def load_data_info(data_file):
    data_info = {}
    if not os.path.exists(data_file):
        return data_info
    with open(data_file, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                item = json.loads(line)
            except json.JSONDecodeError:
                logger.warning("Skipped invalid data jsonl line")
                continue
            dataset_name = item.get('name')
            if dataset_name:
                data_info[dataset_name] = item
    return data_info


def normalize_datasets(payload):
    datasets = []
    if isinstance(payload.get('datasets'), list):
        datasets = payload['datasets']
    elif payload.get('dataset'):
        datasets = [payload['dataset']]
    normalized = []
    for ds in datasets:
        value = (ds or '').strip()
        if value:
            normalized.append(value)
    # keep order and deduplicate
    return list(dict.fromkeys(normalized))


def normalize_modality(raw_modality):
    value = (raw_modality or 'text').strip().lower()
    aliases = {
        'text': 'text',
        'text-only': 'text',
        'text_only': 'text',
        'text-only_modality': 'text',
        'multimodal': 'multimodal',
        'multi-modal': 'multimodal',
    }
    return aliases.get(value)


def get_modality_paths(modality):
    config = MODALITY_CONFIG[modality]
    output_dir = Path(config['output_dir'])
    output_dir.mkdir(parents=True, exist_ok=True)
    return {
        'output_dir': output_dir,
        'graph_file': output_dir / 'graph.jsonl',
        'data_file': output_dir / 'data.jsonl',
        'lock_file': output_dir / '.lineage_write.lock',
        'enable_multimodal': config['enable_multimodal'],
    }


def hf_dataset_exists(dataset_name):
    """Lightweight existence pre-check independent from LLM env."""
    api_url = f"https://huggingface.co/api/datasets/{dataset_name}"
    page_url = f"https://huggingface.co/datasets/{dataset_name}"
    for url in (api_url, page_url):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                if resp.status == 200:
                    return True
        except urllib.error.HTTPError as exc:
            if exc.code == 404:
                continue
        except Exception:
            # network errors are treated as uncertain, let downstream pipeline decide
            return True
    return False


@app.route('/api/lineage/query', methods=['POST'])
def query_lineage():
    """Query cached lineage or process dataset in real time."""
    try:
        payload = request.json or {}
        datasets = normalize_datasets(payload)
        max_depth = payload.get('depth', 6)
        model_config = payload.get('model_config')
        modality = normalize_modality(payload.get('modality', 'text'))

        if not datasets:
            return jsonify({'error': 'dataset or datasets is required'}), 400

        if modality not in MODALITY_CONFIG:
            return jsonify({
                'error': 'invalid_modality',
                'message': 'modality must be one of: text, multimodal'
            }), 400

        invalid = [d for d in datasets if not DATASET_PATTERN.match(d)]
        if invalid:
            return jsonify({
                'error': 'invalid_dataset_format',
                'message': f"Invalid dataset format: {', '.join(invalid)}. Expected org/name",
                'invalid_datasets': invalid
            }), 400

        if not isinstance(max_depth, int) or max_depth < 1:
            return jsonify({'error': 'depth must be an integer >= 1'}), 400

        modality_paths = get_modality_paths(modality)
        data_info = load_data_info(str(modality_paths['data_file']))
        missing = [d for d in datasets if d not in data_info]
        not_found = []

        if missing:
            with LINEAGE_PROCESS_LOCK:
                with file_lock(str(modality_paths['lock_file'])):
                    # double-check after lock to avoid repeated processing
                    data_info = load_data_info(str(modality_paths['data_file']))
                    missing = [d for d in datasets if d not in data_info]
                    for dataset_name in missing:
                        if not hf_dataset_exists(dataset_name):
                            not_found.append(dataset_name)
                            continue
                        if not os.getenv('OPENAI_API_KEY'):
                            return jsonify({
                                'error': 'runtime_not_configured',
                                'message': 'OPENAI_API_KEY is required for realtime lineage processing',
                                'dataset': dataset_name
                            }), 503
                        try:
                            process_single_dataset(
                                dataset_name=dataset_name,
                                output_dir=str(modality_paths['output_dir']),
                                max_depth=max_depth,
                                model_config=model_config,
                                enable_multimodal=modality_paths['enable_multimodal'],
                            )
                        except DatasetNotFoundError:
                            not_found.append(dataset_name)
                        except DatasetFormatError as exc:
                            return jsonify({'error': 'invalid_dataset_format', 'message': str(exc)}), 400
                        except Exception as exc:
                            logger.error(f"Failed processing dataset {dataset_name}: {exc}", exc_info=True)
                            return jsonify({
                                'error': 'processing_failed',
                                'message': f'Failed to process dataset {dataset_name}: {str(exc)}'
                            }), 500

        if not_found:
            return jsonify({
                'error': 'dataset_not_found',
                'message': f"Dataset not found on Hugging Face: {', '.join(not_found)}",
                'datasets': not_found
            }), 404

        graph_data = load_graph_data(str(modality_paths['graph_file']))
        data_info = load_data_info(str(modality_paths['data_file']))
        still_missing = [d for d in datasets if d not in data_info]
        if still_missing:
            return jsonify({
                'error': 'dataset_not_available',
                'message': f"Datasets unavailable after processing: {', '.join(still_missing)}",
                'datasets': still_missing
            }), 404

        return jsonify({
            'success': True,
            'modality': modality,
            'from_cache': len(missing) == 0,
            'processed_datasets': missing,
            'graphData': graph_data,
            'dataInfo': data_info
        })
    except Exception as exc:
        logger.error(f"Error in /api/lineage/query: {exc}", exc_info=True)
        return jsonify({'error': 'internal_error', 'message': str(exc)}), 500


@app.route('/api/lineage/bootstrap', methods=['GET'])
def lineage_bootstrap():
    """Load current graph/data by modality for initial UI render."""
    try:
        modality = normalize_modality(request.args.get('modality', 'text'))
        if modality not in MODALITY_CONFIG:
            return jsonify({
                'error': 'invalid_modality',
                'message': 'modality must be one of: text, multimodal'
            }), 400

        modality_paths = get_modality_paths(modality)
        return jsonify({
            'success': True,
            'modality': modality,
            'graphData': load_graph_data(str(modality_paths['graph_file'])),
            'dataInfo': load_data_info(str(modality_paths['data_file'])),
        })
    except Exception as exc:
        logger.error(f"Error in /api/lineage/bootstrap: {exc}", exc_info=True)
        return jsonify({'error': 'internal_error', 'message': str(exc)}), 500

@app.route('/api/summarize-sources', methods=['POST'])
def summarize_sources():
    """Summarize source data composition characteristics for target data"""
    try:
        data = request.json
        if not data:
            return jsonify({'error': 'Request body is required and must be valid JSON'}), 400
        
        target_name = data.get('target_name')
        target_info = data.get('target_info', {})
        source_data_list = data.get('source_data_list', [])
        source_info_map = data.get('source_info_map', {})
        language = data.get('language', 'zh')  # Get language parameter, default to 'zh'
        benchmark_contamination = data.get('benchmark_contamination', [])  # [[benchmark, ..., target], ...]
        
        if not target_name:
            return jsonify({'error': 'target_name is required'}), 400
        
        if not source_data_list:
            return jsonify({'error': 'source_data_list is required'}), 400
        
        if not llm:
            return jsonify({'error': 'LLM not initialized. Please check OPENAI_API_KEY environment variable.'}), 500
        
        # Select prompt template based on language
        if language == 'en':
            prompt_template = SOURCE_SUMMARY_PROMPT_EN
            no_desc_text = 'No description'
            no_category_text = 'Unclassified'
            unknown_type_text = 'Unknown type'
            no_valid_source_text = 'No valid source data information'
            desc_label = 'Description: '
            category_label = 'Categories: '
            type_label = 'Type: '
        else:
            prompt_template = SOURCE_SUMMARY_PROMPT_ZH
            no_desc_text = '暂无描述'
            no_category_text = '未分类'
            unknown_type_text = '未知类型'
            no_valid_source_text = '暂无有效的source data信息'
            desc_label = '描述：'
            category_label = '类别：'
            type_label = '类型：'
        
        # Get target data description information
        target_description = target_info.get('summary', no_desc_text)
        target_categories = ', '.join(target_info.get('categories', [])) if target_info.get('categories') else no_category_text
        target_data_type = target_info.get('data_type', unknown_type_text)
        
        # Build source data list string (must include description information)
        source_list_items = []
        
        for source in source_data_list:
            source_name = source.get('name', '')
            source_info = source_info_map.get(source_name, {})
            
            # Only process datasets with info (frontend has already filtered exists_on_hf)
            if not source_info:
                continue
            
            # Build source data information, must include description
            item = f"- {source_name}"
            source_description = source_info.get('summary', '')
            if source_description:
                item += f"\n  {desc_label}{source_description}"
            else:
                item += f"\n  {desc_label}{no_desc_text}"
            
            if source_info.get('categories') and len(source_info['categories']) > 0:
                categories = ', '.join(source_info['categories'])
                item += f"\n  {category_label}{categories}"
            if source_info.get('data_type'):
                item += f"\n  {type_label}{source_info['data_type']}"
            
            source_list_items.append(item)
        
        # If no valid source data, return message
        if len(source_list_items) == 0:
            return jsonify({
                'success': True,
                'summary': no_valid_source_text,
                'target_name': target_name
            })
        
        source_list_str = '\n'.join(source_list_items)

        # Compute missing-HF source statistics
        total_source_count = len(source_data_list)
        traceable_count = len(source_list_items)
        missing_sources = [
            s.get('name', '') for s in source_data_list
            if s.get('name') and s.get('name') not in source_info_map
        ]
        if missing_sources:
            missing_names = '、'.join(missing_sources) if language == 'zh' else ', '.join(missing_sources)
            if language == 'zh':
                missing_hf_info = f"（其中 {missing_names} 不在 Hugging Face 上，无法追溯）\n"
                traceability_instruction = (
                    f"注意：该数据集共有 {total_source_count} 个直接来源，"
                    f"但其中 {missing_names} 不在 Hugging Face 上，"
                    f"因此实际可追溯节点为 {traceable_count} 个——请在报告中自然地说明这一差异，无需生硬列举"
                )
            else:
                missing_hf_info = f"(Note: {missing_names} are not on Hugging Face and cannot be traced)\n"
                traceability_instruction = (
                    f"Note: this dataset has {total_source_count} direct sources in total, "
                    f"but {missing_names} are not on Hugging Face, "
                    f"so only {traceable_count} nodes are actually traceable — "
                    f"mention this discrepancy naturally in the report without stiff enumeration"
                )
        else:
            missing_hf_info = ""
            traceability_instruction = (
                "来源数据均在 Hugging Face 上可追溯，无需特别说明，可根据内容需要自然带过或不提"
                if language == 'zh'
                else "All source datasets are traceable on Hugging Face; no special note needed — mention only if it adds value"
            )

        # Build benchmark contamination info for prompt
        if benchmark_contamination:
            sep = '、' if language == 'zh' else ', '
            if language == 'zh':
                path_lines = '\n'.join(
                    '  ' + ' → '.join(path) for path in benchmark_contamination
                )
                benchmark_names = sep.join(
                    sorted(set(path[0] for path in benchmark_contamination if path))
                )
                benchmark_info = (
                    f"\n⚠️ Benchmark 污染警告：\n"
                    f"该数据集的来源链中检测到以下 Benchmark（评测集）：{benchmark_names}\n"
                    f"污染路径如下：\n{path_lines}\n"
                )
                benchmark_instruction = (
                    "Benchmark 污染风险：报告中须明确指出该数据集的来源中包含上述 Benchmark 评测集，"
                    "说明可能带来的评测数据污染风险，并给出污染路径（benchmark → ... → 目标数据集），"
                    "语气客观、简洁，融入正文而非单独罗列"
                )
            else:
                path_lines = '\n'.join(
                    '  ' + ' → '.join(path) for path in benchmark_contamination
                )
                benchmark_names = sep.join(
                    sorted(set(path[0] for path in benchmark_contamination if path))
                )
                benchmark_info = (
                    f"\n⚠️ Benchmark Contamination Warning:\n"
                    f"The following benchmark evaluation sets were detected in this dataset's lineage: {benchmark_names}\n"
                    f"Contamination paths:\n{path_lines}\n"
                )
                benchmark_instruction = (
                    "Benchmark contamination risk: the report must explicitly mention that this dataset's lineage "
                    "includes the above benchmark evaluation sets, describe the potential evaluation data contamination risk, "
                    "and include the contamination path (benchmark → ... → target dataset) — "
                    "write it naturally as part of the text, not as a separate list"
                )
        else:
            benchmark_info = ""
            benchmark_instruction = (
                "无 Benchmark 污染风险，无需提及" if language == 'zh'
                else "No benchmark contamination detected; no need to mention it"
            )

        # Check cache (include language and benchmark contamination in cache key)
        cache_key = get_cache_key(target_name, target_info, source_data_list, source_info_map, language, benchmark_contamination)
        cached_result = get_from_cache(cache_key)
        
        if cached_result:
            logger.info(f"Cache hit for {target_name} (language: {language}, key: {cache_key[:8]}...)")
            return jsonify({
                'success': True,
                'summary': cached_result['summary'],
                'target_name': target_name,
                'from_cache': True
            })
        
        # Build prompt using selected template
        prompt = ChatPromptTemplate.from_template(prompt_template)
        messages = prompt.format_messages(
            target_name=target_name,
            target_description=target_description,
            target_categories=target_categories,
            target_data_type=target_data_type,
            total_source_count=total_source_count,
            traceable_count=traceable_count,
            missing_hf_info=missing_hf_info,
            traceability_instruction=traceability_instruction,
            source_list=source_list_str,
            benchmark_info=benchmark_info,
            benchmark_instruction=benchmark_instruction
        )
        
        # Write full prompt to log
        try:
            if messages:
                prompt_text = messages[0].content if hasattr(messages[0], 'content') else str(messages[0])
            else:
                prompt_text = str(messages)
        except Exception as e:
            prompt_text = f"Error extracting prompt: {e}\nMessages: {messages}"
        
        logger.info(f"=== Prompt for {target_name} (language: {language}) ===")
        logger.info(f"\n{prompt_text}\n")
        logger.info(f"=== End of Prompt ===\n")
        
        # Call LLM
        logger.info(f"Summarizing sources for {target_name} (language: {language}, key: {cache_key[:8]}...)...")
        response = llm.invoke(messages)
        summary = response.content.strip()
        
        # Clean summary text (remove possible quotes, etc.)
        summary = summary.strip('"').strip("'").strip()
        
        # Save to cache (cache key already includes language)
        save_cache(cache_key, target_name, summary)
        
        logger.info(f"Summary generated for {target_name} (language: {language}): {summary[:50]}...")
        
        return jsonify({
            'success': True,
            'summary': summary,
            'target_name': target_name,
            'from_cache': False
        })
        
    except Exception as e:
        logger.error(f"Error summarizing sources: {e}", exc_info=True)
        return jsonify({'error': str(e)}), 500

@app.route('/api/health', methods=['GET'])
def health():
    """Health check"""
    return jsonify({
        'status': 'ok',
        'llm_initialized': llm is not None
    })


@app.route('/', methods=['GET'])
def serve_index():
    return send_from_directory(str(CURRENT_DIR), 'index.html')


@app.route('/<path:path>', methods=['GET'])
def serve_static(path):
    return send_from_directory(str(CURRENT_DIR), path)

if __name__ == '__main__':
    # Initialize LLM
    init_llm()
    
    # Start server: host 0.0.0.0 = 监听所有网卡，供内网/外网访问
    host = os.getenv('API_HOST', '0.0.0.0')
    port = int(os.getenv('API_PORT', 8004))
    logger.info(f"Starting API server on {host}:{port}")
    app.run(host=host, port=port, debug=False)

