#!/bin/bash

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEFAULT_CONDA_SH="${HOME}/miniconda3/etc/profile.d/conda.sh"
CONDA_ENV_NAME="${CONDA_ENV_NAME:-count}"

if [ -f "${DEFAULT_CONDA_SH}" ]; then
    # shellcheck disable=SC1090
    source "${DEFAULT_CONDA_SH}"
elif command -v conda >/dev/null 2>&1; then
    eval "$(conda shell.bash hook)"
fi

if command -v conda >/dev/null 2>&1; then
    CURRENT_ENV="${CONDA_DEFAULT_ENV:-}"
    if [ "${CURRENT_ENV}" != "${CONDA_ENV_NAME}" ]; then
        conda activate "${CONDA_ENV_NAME}"
    fi
fi

cd "${SCRIPT_DIR}"

echo "Starting Data Lineage Web Service..."
echo "===================================="
echo ""

# Check required files
if [ ! -f "${SCRIPT_DIR}/api_server.py" ]; then
    echo "Error: api_server.py file not found at ${SCRIPT_DIR}/api_server.py"
    exit 1
fi

# 监听地址：默认 0.0.0.0 表示所有网卡，供内网访问；仅本机可设 API_HOST=127.0.0.1
API_HOST="${API_HOST:-0.0.0.0}"
API_PORT="${API_PORT:-8004}"
export API_HOST
export API_PORT
OPENAI_MODEL="${OPENAI_MODEL:-gpt-5.4}"
export OPENAI_MODEL

echo "Configuration:"
echo "  Bind: ${API_HOST}:${API_PORT}"
echo "  本机访问:  http://localhost:${API_PORT}"
# 尝试获取本机 IP，供内网访问提示（Linux 常见）
if command -v hostname &>/dev/null; then
    LAN_IP=$(hostname -I 2>/dev/null | awk '{print $1}')
    if [ -n "$LAN_IP" ]; then
        echo "  内网访问:  http://${LAN_IP}:${API_PORT}"
    fi
fi
echo "  OPENAI_MODEL: ${OPENAI_MODEL}"
echo "  Python: $(which python)"
if [ -n "${CONDA_DEFAULT_ENV}" ]; then
    echo "  Conda env: ${CONDA_DEFAULT_ENV}"
fi
if [ -n "${OPENAI_BASE_URL}" ]; then
    echo "  OPENAI_BASE_URL: ${OPENAI_BASE_URL}"
fi
if [ -n "${OPENAI_API_KEY}" ]; then
    echo "  OPENAI_API_KEY: ${OPENAI_API_KEY:0:10}..."
else
    echo "  OPENAI_API_KEY: (not set, LLM summary may be unavailable)"
fi
echo ""
echo "若内网无法访问，请检查防火墙是否放行端口 ${API_PORT}（如: firewall-cmd --add-port=${API_PORT}/tcp --permanent && firewall-cmd --reload）"
echo "Press Ctrl+C to stop the server"
echo ""

python api_server.py
