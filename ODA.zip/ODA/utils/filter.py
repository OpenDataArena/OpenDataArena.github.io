#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
数据集筛选脚本
筛选条件：四个平均分（general_avg, math_avg, code_avg, reasoning_avg）
至少有一个比基准（id为1的数据）高5分及以上，则保留
如果四个分数都未达到基准+5分，则去除
"""

import json
import os


def filter_datasets(input_file, output_file=None):
    """
    筛选数据集
    
    Args:
        input_file: 输入的JSON文件路径
        output_file: 输出的JSON文件路径（可选）
    """
    # 读取JSON文件
    with open(input_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    # 需要处理的字段
    fields = ['llama', 'qwen']
    
    # 需要对比的分数字段
    score_keys = ['general_avg', 'math_avg', 'code_avg', 'reasoning_avg']
    
    # 存储筛选后的数据
    filtered_data = {}
    
    # 存储统计信息
    statistics = {}
    
    for field in fields:
        if field not in data:
            print(f"警告：字段 '{field}' 不存在于数据中")
            continue
        
        field_data = data[field]
        
        # 查找id为1的基准数据
        base_data = None
        for item in field_data:
            if item.get('id') == 1:
                base_data = item
                break
        
        if base_data is None:
            print(f"错误：在 '{field}' 中未找到id为1的基准数据")
            continue
        
        # 获取基准分数
        base_scores = {key: base_data.get(key, 0) for key in score_keys}
        
        print(f"\n{'='*60}")
        print(f"处理字段: {field}")
        print(f"基准数据: {base_data.get('name', 'Unknown')}")
        print(f"基准分数:")
        for key, value in base_scores.items():
            print(f"  {key}: {value}")
        
        # 筛选数据
        filtered_items = []
        removed_items = []
        
        for item in field_data:
            item_id = item.get('id')
            item_name = item.get('name', 'Unknown')
            
            # 跳过id为0的数据（Instruct版本）
            if item_id == 0:
                print(f"\n跳过 id=0: {item_name} (Instruct版本)")
                continue
            
            # 跳过id为1的数据（这是基准数据本身）
            if item_id == 1:
                filtered_items.append(item)
                print(f"\n保留 id=1: {item_name} (基准数据)")
                continue
            
            # 检查四个分数
            current_scores = {key: item.get(key, 0) for key in score_keys}
            differences = {key: current_scores[key] - base_scores[key] 
                          for key in score_keys}
            
            # 判断是否满足筛选条件
            # 条件：至少有一个分数比基准高5分及以上
            any_score_high_enough = any(diff >= 5 for diff in differences.values())
            
            if any_score_high_enough:
                filtered_items.append(item)
                print(f"\n✓ 保留 id={item_id}: {item_name}")
                print(f"  分数差值 (达标≥+5分的标记为 ✓):")
                for key, diff in differences.items():
                    marker = " ✓" if diff >= 5 else ""
                    sign = "+" if diff >= 0 else ""
                    print(f"    {key}: {current_scores[key]:.2f} (差值: {sign}{diff:.2f}){marker}")
            else:
                removed_items.append({
                    'id': item_id,
                    'name': item_name,
                    'scores': current_scores,
                    'differences': differences
                })
                print(f"\n✗ 去除 id={item_id}: {item_name}")
                print(f"  分数差值 (达标≥+5分的标记为 ✓):")
                for key, diff in differences.items():
                    marker = " ✓" if diff >= 5 else ""
                    sign = "+" if diff >= 0 else ""
                    print(f"    {key}: {current_scores[key]:.2f} (差值: {sign}{diff:.2f}){marker}")
        
        # 保存筛选后的数据
        filtered_data[field] = filtered_items
        
        # 保存统计信息
        statistics[field] = {
            'base_name': base_data.get('name', 'Unknown'),
            'base_scores': base_scores,
            'total_original': len(field_data),
            'total_filtered': len(filtered_items),
            'total_removed': len(removed_items),
            'kept_items': [{'id': item.get('id'), 'name': item.get('name')} 
                          for item in filtered_items if item.get('id') != 1],
            'removed_items': removed_items
        }
    
    # 打印统计摘要
    print(f"\n{'='*60}")
    print("统计摘要")
    print(f"{'='*60}")
    
    for field, stats in statistics.items():
        print(f"\n字段: {field}")
        print(f"  基准: {stats['base_name']}")
        print(f"  原始数据集数量: {stats['total_original']}")
        print(f"  筛选后数量: {stats['total_filtered']} (包括基准数据)")
        print(f"  保留数量: {len(stats['kept_items'])} (不包括基准数据)")
        print(f"  去除数量: {stats['total_removed']}")
        
        if stats['kept_items']:
            print(f"  保留的数据集:")
            for item in stats['kept_items']:
                print(f"    - id={item['id']}: {item['name']}")
    
    # 如果指定了输出文件，保存筛选后的数据
    if output_file:
        # 保留原始数据中的其他字段（如qwen3等）
        output_data = data.copy()
        output_data.update(filtered_data)
        
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(output_data, f, ensure_ascii=False, indent=2)
        print(f"\n筛选后的数据已保存到: {output_file}")
    
    # 保存统计信息到JSON文件
    stats_file = os.path.join(os.path.dirname(input_file), 'filter_statistics.json')
    with open(stats_file, 'w', encoding='utf-8') as f:
        json.dump(statistics, f, ensure_ascii=False, indent=2)
    print(f"统计信息已保存到: {stats_file}")
    
    # 保存简洁的筛选结果（仅包含id和name）
    results_summary = {}
    for field, stats in statistics.items():
        results_summary[field] = {
            'base': {
                'name': stats['base_name'],
                'scores': stats['base_scores']
            },
            'kept': [{'id': item['id'], 'name': item['name']} for item in stats['kept_items']],
            'removed': [{'id': item['id'], 'name': item['name']} for item in stats['removed_items']],
            'summary': {
                'total_original': stats['total_original'],
                'total_kept': len(stats['kept_items']),
                'total_removed': stats['total_removed']
            }
        }
    
    results_file = os.path.join(os.path.dirname(input_file), 'filter_results.json')
    with open(results_file, 'w', encoding='utf-8') as f:
        json.dump(results_summary, f, ensure_ascii=False, indent=2)
    print(f"筛选结果已保存到: {results_file}")
    
    return filtered_data, statistics


if __name__ == '__main__':
    # 输入文件路径
    input_file = 'data/processed_leaderboard_data.json'
    
    # 输出文件路径（可选，如果不需要保存筛选后的数据，可以设为None）
    output_file = 'data/filtered_leaderboard_data.json'
    
    # 执行筛选
    filtered_data, statistics = filter_datasets(input_file, output_file)
    
    print(f"\n{'='*60}")
    print("筛选完成！")
    print(f"{'='*60}")

