"""
列配置示例文件

这个文件展示了如何在 1_excel.py 中配置不同sheet的列索引

使用方法：
1. 复制下面的配置代码
2. 粘贴到 1_excel.py 的 ExcelProcessor 类中，替换 SHEET_SPECIFIC_COLUMN_CONFIG
3. 根据实际的Excel文件调整列索引
"""

# ============================================
# 示例1：单个特定sheet配置
# ============================================

SHEET_SPECIFIC_COLUMN_CONFIG = {
    "gemma": {
        "general_cols": list(range(4, 8)),      # E-H列 (索引4-7)
        "math_cols": list(range(8, 14)),        # I-N列 (索引8-13)
        "code_cols": list(range(14, 18)),       # O-R列 (索引14-17)
        "reasoning_cols": list(range(18, 23)),  # S-W列 (索引18-22)
    }
}

# ============================================
# 示例2：多个sheet使用不同配置
# ============================================

SHEET_SPECIFIC_COLUMN_CONFIG = {
    "gemma": {
        "general_cols": list(range(4, 8)),      # E-H列
        "math_cols": list(range(8, 14)),        # I-N列
        "code_cols": list(range(14, 18)),       # O-R列
        "reasoning_cols": list(range(18, 23)),  # S-W列
    },
    "mistral": {
        "general_cols": list(range(2, 6)),      # C-F列
        "math_cols": list(range(6, 11)),        # G-K列
        "code_cols": list(range(11, 15)),       # L-O列
        "reasoning_cols": list(range(15, 20)),  # P-T列
    },
    "phi": {
        "general_cols": list(range(5, 9)),      # F-I列
        "math_cols": list(range(9, 14)),        # J-N列
        "code_cols": list(range(14, 18)),       # O-R列
        "reasoning_cols": list(range(18, 23)),  # S-W列
    }
}

# ============================================
# 示例3：某些domain的列数不同
# ============================================

SHEET_SPECIFIC_COLUMN_CONFIG = {
    "special_sheet": {
        "general_cols": list(range(3, 8)),      # D-H列 (5列，比默认多1列)
        "math_cols": list(range(8, 11)),        # I-K列 (3列，比默认少2列)
        "code_cols": list(range(11, 16)),       # L-P列 (5列，比默认多1列)
        "reasoning_cols": list(range(16, 21)),  # Q-U列 (5列，与默认相同)
    }
}

# ============================================
# 列索引快速参考表
# ============================================
"""
索引 -> Excel列字母映射：

0  -> A    10 -> K    20 -> U
1  -> B    11 -> L    21 -> V
2  -> C    12 -> M    22 -> W
3  -> D    13 -> N    23 -> X
4  -> E    14 -> O    24 -> Y
5  -> F    15 -> P    25 -> Z
6  -> G    16 -> Q
7  -> H    17 -> R
8  -> I    18 -> S
9  -> J    19 -> T

range(3, 7)  = [3, 4, 5, 6]     = D, E, F, G
range(7, 12) = [7, 8, 9, 10, 11] = H, I, J, K, L
range(12, 16) = [12, 13, 14, 15] = M, N, O, P
range(16, 21) = [16, 17, 18, 19, 20] = Q, R, S, T, U
"""

# ============================================
# 实际操作步骤
# ============================================
"""
步骤1: 打开 1_excel.py 文件

步骤2: 找到 ExcelProcessor 类中的 SHEET_SPECIFIC_COLUMN_CONFIG

步骤3: 根据您的Excel文件，修改配置。例如：

    class ExcelProcessor:
        # ... 其他代码 ...
        
        SHEET_SPECIFIC_COLUMN_CONFIG = {
            "新sheet名称": {
                "general_cols": list(range(起始索引, 结束索引+1)),
                "math_cols": list(range(起始索引, 结束索引+1)),
                "code_cols": list(range(起始索引, 结束索引+1)),
                "reasoning_cols": list(range(起始索引, 结束索引+1)),
            }
        }

步骤4: 保存文件并运行测试

    python 1_excel.py

步骤5: 检查日志输出，确认使用了正确的配置

    查看日志中的这一行：
    - "使用默认列配置:" 或
    - "使用 [sheet名称] 特定的列配置:"
"""

# ============================================
# 常见问题解答
# ============================================
"""
Q1: 为什么 range(3, 7) 只包含 [3, 4, 5, 6] 而不包含7？
A1: Python的range函数不包含结束值。要包含索引7，应该写 range(3, 8)

Q2: 如何知道我的Excel文件中各列的索引？
A2: 运行程序后查看日志，会显示检测到的列信息

Q3: 可以只配置某个domain吗？
A3: 不可以，必须配置所有4个domain（general, math, code, reasoning）

Q4: 如果配置错误会怎样？
A4: 程序可能读取到错误的数据，或者某些benchmark的分数为空

Q5: 如何测试配置是否正确？
A5: 运行程序后检查日志输出和生成的JSON文件，确认数据是否正确
"""

