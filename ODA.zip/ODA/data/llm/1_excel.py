"""
OpenDataArena Excel数据处理模块

该模块用于处理Excel文件中的模型性能数据，生成结构化的JSON数据用于排行榜显示。
主要功能包括：
1. 解析Excel文件中的数据集和模型信息
2. 计算各领域平均分数和性价比
3. 生成基准模型对比数据
4. 输出结构化的JSON数据

"""

import pandas as pd
import json
import numpy as np
import logging
import sys
from datetime import datetime
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass, field


def setup_logging(log_file: str = None, log_level: str = "INFO") -> logging.Logger:
    """
    设置日志配置

    Args:
        log_file: 日志文件路径，如果为None则只输出到控制台
        log_level: 日志级别 (DEBUG, INFO, WARNING, ERROR, CRITICAL)

    Returns:
        配置好的logger对象
    """
    # 创建logger
    logger = logging.getLogger("excel_processor")
    logger.setLevel(getattr(logging, log_level.upper()))

    # 清除已有的处理器
    logger.handlers.clear()

    # 创建格式化器
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # 控制台处理器
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(getattr(logging, log_level.upper()))
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    # 文件处理器（如果指定了日志文件）
    if log_file:
        file_handler = logging.FileHandler(log_file, encoding="utf-8")
        file_handler.setLevel(getattr(logging, log_level.upper()))
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

    return logger


@dataclass
class TaskDetail:
    """任务详细信息数据类"""

    task_name: str
    metrics: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class ModelInfo:
    """模型信息数据类"""

    id: int
    name: str
    domain: str
    general_avg: float = 0.0
    math_avg: float = 0.0
    code_avg: float = 0.0
    reasoning_avg: float = 0.0
    overall_avg: float = 0.0
    overall_efficiency: float = 0.0
    general_efficiency: float = 0.0
    math_efficiency: float = 0.0
    code_efficiency: float = 0.0
    reasoning_efficiency: float = 0.0
    general_task_scores: List[float] = field(default_factory=list)
    math_task_scores: List[float] = field(default_factory=list)
    code_task_scores: List[float] = field(default_factory=list)
    reasoning_task_scores: List[float] = field(default_factory=list)
    task_details: Dict[str, List[TaskDetail]] = field(default_factory=dict)
    improvement: Dict[str, Any] = field(default_factory=dict)

    # 数据集属性
    affiliation: str = ""
    year: str = ""
    size: str = ""
    size_precise: str = ""
    link: str = ""
    paper_link: str = ""
    scored_link: str = ""
    tag: str = ""


class ExcelProcessor:
    """Excel数据处理器主类"""

    # 默认列配置
    # NOTE(zzp): col index
    DEFAULT_COLUMN_CONFIG = {
        "general_cols": list(range(3, 7)),  # D-G列
        "math_cols": list(range(7, 12)),  # H-L列
        "code_cols": list(range(12, 16)),  # M-P列
        "reasoning_cols": list(range(16, 21)),  # Q-U列
    }
    
    # 特定sheet的列配置（如果某个sheet的列配置与默认不同，在此定义）
    SHEET_SPECIFIC_COLUMN_CONFIG = {
        # 示例：如果某个sheet的列不同，可以这样定义：
        "qwen3": {
            "general_cols": list(range(3, 7)),
            "math_cols": list(range(7, 16)),
            "code_cols": list(range(16, 20)),
            "reasoning_cols": list(range(20, 25)),
        }
    }

    # 领域关键词
    DOMAIN_KEYWORDS = ["general", "math", "code", "reasoning"]

    def __init__(self, excel_file: str = "llm_0228.xlsx", logger: logging.Logger = None):
        """
        初始化Excel处理器

        Args:
            excel_file: Excel文件路径
            logger: 日志记录器，如果为None则创建默认logger
        """
        self.excel_file = excel_file
        self.dataset_attr_map = {}
        self.processed_data = {}
        self.logger = logger or logging.getLogger("excel_processor")

    def load_dataset_attributes(self) -> None:
        """加载数据集属性信息并分配固定编号"""
        self.logger.info("--- 加载数据集属性信息 ---")

        try:
            df_dataset = pd.read_excel(
                self.excel_file, sheet_name="datasets_info", header=None
            )

            # 从第2行开始提取数据集属性
            dataset_id = 2  # 从2开始分配ID（0和1预留给instruct和base模型）
            
            for idx in range(1, len(df_dataset)):
                name = df_dataset.iloc[idx, 1] if idx < len(df_dataset) else None

                if pd.notna(name):
                    name_str = str(name).strip()
                    
                    # 跳过表头行和无效名称
                    if name_str.lower() in ['none', 'affiliation', 'year', 'size', 'link', 'paper_link', 'scored_link', 'tag'] or len(name_str) == 0:
                        continue

                    # 提取各种属性
                    # NOTE(zzp)
                    attributes = {
                        "id": dataset_id,  # 分配固定ID
                        "affiliation": self._safe_get_cell(df_dataset, idx, 2),
                        "year": self._safe_get_cell(df_dataset, idx, 3),
                        "size": self._safe_get_cell(df_dataset, idx, 4),
                        "size_precise": self._safe_get_cell(df_dataset, idx, 5),
                        "link": self._safe_get_cell(df_dataset, idx, 7),
                        "paper_link": self._safe_get_cell(df_dataset, idx, 8),
                        "scored_link": self._safe_get_cell(df_dataset, idx, 9),
                        "tag": self._process_tags(
                            self._safe_get_cell(df_dataset, idx, 6)
                        ),
                    }

                    self.dataset_attr_map[name_str] = attributes
                    dataset_id += 1  # 为下一个数据集分配ID

            self.logger.info(f"成功加载 {len(self.dataset_attr_map)} 个数据集属性，ID范围: 2-{dataset_id-1}")

        except Exception as e:
            self.logger.error(f"加载数据集属性时出错: {e}")
            self.dataset_attr_map = {}

    def _safe_get_cell(self, df: pd.DataFrame, row: int, col: int) -> str:
        """安全获取单元格值"""
        if row < len(df) and col < len(df.columns):
            val = df.iloc[row, col]
            return str(val).strip() if pd.notna(val) else ""
        return ""

    def _process_tags(self, tag_str: str) -> str:
        """处理标签字符串"""
        if not tag_str or not str(tag_str).strip():
            return ""

        tags = [t.strip() for t in str(tag_str).strip().split(",") if t.strip()]
        return ",".join(tags)

    def detect_column_layout(self, df_raw: pd.DataFrame, sheet_name: str = None) -> Dict[str, Any]:
        """
        检测列布局和任务信息

        Args:
            df_raw: 原始数据DataFrame
            sheet_name: 工作表名称（用于获取特定的列配置）

        Returns:
            包含列配置和任务信息的字典
        """
        self.logger.info("\n--- 检测表头和列布局 ---")

        # 检测表头行
        header_row = self._find_header_row(df_raw)

        # 根据sheet名称选择列配置
        if sheet_name and sheet_name in self.SHEET_SPECIFIC_COLUMN_CONFIG:
            config = self.SHEET_SPECIFIC_COLUMN_CONFIG[sheet_name].copy()
            self.logger.info(f"使用 {sheet_name} 特定的列配置:")
        else:
            config = self.DEFAULT_COLUMN_CONFIG.copy()
            self.logger.info("使用默认列配置:")
        
        for domain, cols in config.items():
            col_letters = [chr(65 + i) for i in cols]
            self.logger.info(
                f"  {domain.replace('_cols', '').upper()}: 列 {col_letters} (索引 {cols})"
            )

        # 提取任务信息
        task_info = self._extract_task_info(df_raw, config)
        config.update(task_info)

        return config

    def _find_header_row(self, df_raw: pd.DataFrame) -> Optional[int]:
        """查找表头行"""
        header_keywords = ["general", "math", "code", "reasoning", "dataset", "model"]

        for i in range(min(5, len(df_raw))):
            row = df_raw.iloc[i]
            row_text = " ".join([str(cell).lower() for cell in row if pd.notna(cell)])
            if any(keyword in row_text for keyword in header_keywords):
                self.logger.info(f"找到表头行: {i+1}")
                return i
        return None

    def _extract_task_info(
        self, df_raw: pd.DataFrame, column_config: Dict
    ) -> Dict[str, List[str]]:
        """提取任务名称和指标信息"""
        self.logger.info("\n--- 提取小任务信息 ---")

        task_info = {}

        if len(df_raw) > 2:
            task_name_row = df_raw.iloc[1]
            metric_name_row = df_raw.iloc[2]

            for domain in ["general", "math", "code", "reasoning"]:
                col_key = f"{domain}_cols"
                if col_key in column_config:
                    cols = column_config[col_key]

                    task_names, metric_names = self._extract_domain_tasks(
                        task_name_row, metric_name_row, cols, domain
                    )

                    task_info[f"{domain}_tasks"] = task_names
                    task_info[f"{domain}_metrics"] = metric_names

                    self.logger.info(f"  {domain.upper()}:")
                    for i, (task, metric) in enumerate(zip(task_names, metric_names)):
                        col_letter = chr(65 + cols[i])
                        self.logger.info(f"    {col_letter}: {task} ({metric})")

        return task_info

    def _extract_domain_tasks(
        self, task_row: pd.Series, metric_row: pd.Series, cols: List[int], domain: str
    ) -> Tuple[List[str], List[str]]:
        """提取特定领域的任务和指标信息"""
        task_names = []
        metric_names = []
        current_task_name = None

        for col_idx in cols:
            # 提取任务名称
            if col_idx < len(task_row):
                task_name = task_row.iloc[col_idx]
                if pd.notna(task_name) and str(task_name).strip():
                    current_task_name = str(task_name).strip()
                    task_names.append(current_task_name)
                else:
                    if current_task_name:
                        task_names.append(current_task_name)
                    else:
                        task_names.append(f"Task_{col_idx}")
            else:
                if current_task_name:
                    task_names.append(current_task_name)
                else:
                    task_names.append(f"Task_{col_idx}")

            # 提取指标名称
            if col_idx < len(metric_row):
                metric_name = metric_row.iloc[col_idx]
                if pd.notna(metric_name) and str(metric_name).strip():
                    metric_names.append(str(metric_name).strip())
                else:
                    metric_names.append(f"Metric_{col_idx}")
            else:
                metric_names.append(f"Metric_{col_idx}")

        return task_names, metric_names

    def detect_domain_ranges(self, df_raw: pd.DataFrame) -> Dict[str, Tuple[int, int]]:
        """
        检测各领域在Excel中的行范围

        Args:
            df_raw: 原始数据DataFrame

        Returns:
            领域名称到(开始行, 结束行)的映射
        """
        self.logger.info("\n--- 检测领域分布 ---")

        domain_ranges = {}
        domain_starts = {}

        # 查找各领域开始行
        for i in range(len(df_raw)):
            a_val = df_raw.iloc[i, 0]
            if pd.notna(a_val):
                a_str = str(a_val).strip().lower()
                if a_str in self.DOMAIN_KEYWORDS:
                    domain_starts[a_str] = i
                    self.logger.info(f"找到领域 '{a_str}' 开始于行 {i+1}")

        # 计算各领域范围
        sorted_domains = sorted(domain_starts.items(), key=lambda x: x[1])

        for i, (domain, start_row) in enumerate(sorted_domains):
            if i < len(sorted_domains) - 1:
                end_row = sorted_domains[i + 1][1] - 1
            else:
                end_row = len(df_raw) - 1

            domain_ranges[domain] = (start_row, end_row)
            self.logger.info(f"  {domain}: 行 {start_row+1} - {end_row+1}")

        return domain_ranges

    def determine_dataset_domain(
        self, row_num: int, domain_ranges: Dict[str, Tuple[int, int]]
    ) -> str:
        """根据行号确定数据集所属领域"""
        for domain, (start_row, end_row) in domain_ranges.items():
            if start_row <= row_num <= end_row:
                return domain
        return "unknown"

    def extract_task_scores(
        self, rows: List[pd.Series], col_indices: List[int]
    ) -> List[Optional[float]]:
        """
        为每个小任务提取分数（按列计算平均值）

        Args:
            rows: 数据行列表
            col_indices: 列索引列表

        Returns:
            任务分数列表，None表示无数据
        """
        task_scores = []

        for col_idx in col_indices:
            col_values = []
            for row in rows:
                if col_idx < len(row):
                    val = row.iloc[col_idx]
                    if pd.notna(val):
                        try:
                            num_val = float(val)
                            col_values.append(num_val)
                        except (ValueError, TypeError):
                            continue

            # 如果该列有有效数据，计算平均值；否则返回None
            if col_values:
                task_scores.append(round(np.mean(col_values), 2))
            else:
                task_scores.append(None)

        return task_scores

    def extract_domain_scores(
        self, rows: List[pd.Series], col_indices: List[int]
    ) -> List[float]:
        """从指定行和列提取有效数值"""
        scores = []
        for row in rows:
            for col_idx in col_indices:
                if col_idx < len(row):
                    val = row.iloc[col_idx]
                    if pd.notna(val):
                        try:
                            num_val = float(val)
                            scores.append(num_val)
                        except (ValueError, TypeError):
                            continue
        return scores

    def calculate_efficiency_score(
        self, avg_score: float, size_precise_str: str
    ) -> float:
        """
        计算数据性价比分数：平均分数 / 数据量 * 1000

        Args:
            avg_score: 平均分数
            size_precise_str: 数据量字符串

        Returns:
            性价比分数
        """
        if not size_precise_str or avg_score <= 0:
            return 0

        try:
            size_str = str(size_precise_str).strip().lower()

            # 处理常见的数字格式
            if "k" in size_str:
                size = float(size_str.replace("k", "")) * 1000
            elif "m" in size_str:
                size = float(size_str.replace("m", "")) * 1000000
            elif "b" in size_str:
                size = float(size_str.replace("b", "")) * 1000000000
            else:
                size = float(size_str)

            if size > 0:
                efficiency = (avg_score / size) * 1000
                return round(efficiency, 6)
            else:
                return 0
        except (ValueError, TypeError):
            return 0

    def organize_tasks_by_name(
        self, tasks: List[str], metrics: List[str], scores: List[Optional[float]]
    ) -> List[TaskDetail]:
        """
        将相同任务名称的不同指标组织在一起

        Args:
            tasks: 任务名称列表
            metrics: 指标名称列表
            scores: 分数列表

        Returns:
            组织后的任务详情列表
        """
        organized_tasks = {}

        for task_name, metric_name, score in zip(tasks, metrics, scores):
            # 跳过无数据的任务
            if score is None:
                continue

            if task_name not in organized_tasks:
                organized_tasks[task_name] = TaskDetail(task_name=task_name)

            organized_tasks[task_name].metrics.append(
                {"metric": metric_name, "score": score}
            )

        return list(organized_tasks.values())

    def create_model_info(
        self,
        model_type: str,
        sheet_name: str,
        row: Optional[pd.Series],
        column_layout: Dict,
        domain_ranges: Dict,
    ) -> ModelInfo:
        """
        创建模型信息对象

        Args:
            model_type: 模型类型 ('base' 或 'instruct')
            sheet_name: 工作表名称
            row: 数据行
            column_layout: 列布局配置
            domain_ranges: 领域范围

        Returns:
            模型信息对象
        """
        # 设置模型名称
        if model_type == "base":
            if sheet_name == "llama":
                name = "Llama-3.1-8B"
            elif sheet_name == "qwen":
                name = "Qwen2.5-7B"
            elif sheet_name == "qwen3":
                name = "Qwen3-8B-base"
            else:
                name = "base"
            model_id = 1
        elif model_type == "instruct":  # instruct
            if sheet_name == "llama":
                name = "Llama-3.1-8B-Instruct"
            elif sheet_name == "qwen":
                name = "Qwen2.5-7B-Instruct"
            elif sheet_name == "qwen3":
                name = "Qwen3-8B"
            else:
                name = "instruct"
            model_id = 0

        if row is None:
            # 创建空模型信息
            return ModelInfo(id=model_id, name=name, domain=model_type, task_details={})

        # 提取各领域分数
        general_cols = column_layout["general_cols"]
        math_cols = column_layout["math_cols"]
        code_cols = column_layout["code_cols"]
        reasoning_cols = column_layout["reasoning_cols"]

        general_task_scores = self._extract_base_task_scores(row, general_cols)
        math_task_scores = self._extract_base_task_scores(row, math_cols)
        code_task_scores = self._extract_base_task_scores(row, code_cols)
        reasoning_task_scores = self._extract_base_task_scores(row, reasoning_cols)

        # 计算平均分
        general_avg = np.mean(general_task_scores) if general_task_scores else 0
        math_avg = np.mean(math_task_scores) if math_task_scores else 0
        code_avg = np.mean(code_task_scores) if code_task_scores else 0
        reasoning_avg = np.mean(reasoning_task_scores) if reasoning_task_scores else 0

        valid_averages = [
            avg for avg in [general_avg, math_avg, code_avg, reasoning_avg] if avg > 0
        ]
        overall_avg = np.mean(valid_averages) if valid_averages else 0

        self.logger.info(
            f"{model_type.capitalize()}行分数 - General: {general_avg:.2f}, Math: {math_avg:.2f}, "
            f"Code: {code_avg:.2f}, Reasoning: {reasoning_avg:.2f}, Overall: {overall_avg:.2f}"
        )

        # 构建任务详情
        task_details = {}
        for domain in ["general", "math", "code", "reasoning"]:
            if f"{domain}_tasks" in column_layout:
                task_scores = locals()[f"{domain}_task_scores"]
                if task_scores:
                    task_details[f"{domain}_tasks"] = self.organize_tasks_by_name(
                        column_layout[f"{domain}_tasks"],
                        column_layout[f"{domain}_metrics"],
                        task_scores,
                    )

        return ModelInfo(
            id=model_id,
            name=name,
            domain=model_type,
            general_avg=round(general_avg, 2),
            math_avg=round(math_avg, 2),
            code_avg=round(code_avg, 2),
            reasoning_avg=round(reasoning_avg, 2),
            overall_avg=round(overall_avg, 2),
            general_task_scores=general_task_scores,
            math_task_scores=math_task_scores,
            code_task_scores=code_task_scores,
            reasoning_task_scores=reasoning_task_scores,
            task_details=task_details,
        )

    def _extract_base_task_scores(
        self, row: pd.Series, col_indices: List[int]
    ) -> List[float]:
        """从base行提取各列的分数，值为0参与计算，空值不参与计算"""
        task_scores = []
        for col_idx in col_indices:
            if col_idx < len(row):
                val = row.iloc[col_idx]
                if pd.notna(val):
                    try:
                        task_scores.append(float(val))
                    except (ValueError, TypeError):
                        pass
        return task_scores

    def process_dataset(
        self,
        dataset_name: str,
        dataset_rows: List[pd.Series],
        domain: str,
        column_layout: Dict,
        base_info: ModelInfo,
        instruct_info: ModelInfo,
    ) -> Optional[ModelInfo]:
        """
        处理单个数据集

        Args:
            dataset_name: 数据集名称
            dataset_rows: 数据集行数据
            domain: 数据集领域
            column_layout: 列布局配置
            base_info: 基准模型信息
            instruct_info: 指导模型信息

        Returns:
            处理后的数据集信息对象
        """
        self.logger.info(f"\n处理数据集: {dataset_name} [领域: {domain}]")

        if len(dataset_rows) < 4:
            self.logger.warning(f"警告: 数据集 {dataset_name} 数据行不足4行")
            return None

        # 从预分配的属性中获取ID
        dataset_attr = self.dataset_attr_map.get(dataset_name, {})
        dataset_id = dataset_attr.get('id', 999)  # 如果找不到，使用999作为默认ID

        # 提取各领域分数
        general_cols = column_layout["general_cols"]
        math_cols = column_layout["math_cols"]
        code_cols = column_layout["code_cols"]
        reasoning_cols = column_layout["reasoning_cols"]

        general_scores = self.extract_domain_scores(dataset_rows, general_cols)
        math_scores = self.extract_domain_scores(dataset_rows, math_cols)
        code_scores = self.extract_domain_scores(dataset_rows, code_cols)
        reasoning_scores = self.extract_domain_scores(dataset_rows, reasoning_cols)

        general_task_scores = self.extract_task_scores(dataset_rows, general_cols)
        math_task_scores = self.extract_task_scores(dataset_rows, math_cols)
        code_task_scores = self.extract_task_scores(dataset_rows, code_cols)
        reasoning_task_scores = self.extract_task_scores(dataset_rows, reasoning_cols)

        self.logger.info(
            f"  General: {len(general_scores)} 个有效数据, {len(general_task_scores)} 个任务"
        )
        self.logger.info(
            f"  Math: {len(math_scores)} 个有效数据, {len(math_task_scores)} 个任务"
        )
        self.logger.info(
            f"  Code: {len(code_scores)} 个有效数据, {len(code_task_scores)} 个任务"
        )
        self.logger.info(
            f"  Reasoning: {len(reasoning_scores)} 个有效数据, {len(reasoning_task_scores)} 个任务"
        )

        # 计算平均分
        general_avg = np.mean(general_scores) if general_scores else 0
        math_avg = np.mean(math_scores) if math_scores else 0
        code_avg = np.mean(code_scores) if code_scores else 0
        reasoning_avg = np.mean(reasoning_scores) if reasoning_scores else 0

        valid_averages = [
            avg for avg in [general_avg, math_avg, code_avg, reasoning_avg] if avg > 0
        ]
        overall_avg = np.mean(valid_averages) if valid_averages else 0

        # 计算性价比分数
        dataset_attr = self.dataset_attr_map.get(dataset_name, {})
        size_precise = dataset_attr.get("size_precise", "")

        overall_efficiency = self.calculate_efficiency_score(overall_avg, size_precise)
        general_efficiency = self.calculate_efficiency_score(general_avg, size_precise)
        math_efficiency = self.calculate_efficiency_score(math_avg, size_precise)
        code_efficiency = self.calculate_efficiency_score(code_avg, size_precise)
        reasoning_efficiency = self.calculate_efficiency_score(
            reasoning_avg, size_precise
        )

        # 计算相对于base模型的性价比涨跌
        base_overall_efficiency = self.calculate_efficiency_score(
            base_info.overall_avg, size_precise
        )
        base_general_efficiency = self.calculate_efficiency_score(
            base_info.general_avg, size_precise
        )
        base_math_efficiency = self.calculate_efficiency_score(
            base_info.math_avg, size_precise
        )
        base_code_efficiency = self.calculate_efficiency_score(
            base_info.code_avg, size_precise
        )
        base_reasoning_efficiency = self.calculate_efficiency_score(
            base_info.reasoning_avg, size_precise
        )

        overall_efficiency_delta = round(
            overall_efficiency - base_overall_efficiency, 6
        )
        general_efficiency_delta = round(
            general_efficiency - base_general_efficiency, 6
        )
        math_efficiency_delta = round(math_efficiency - base_math_efficiency, 6)
        code_efficiency_delta = round(code_efficiency - base_code_efficiency, 6)
        reasoning_efficiency_delta = round(
            reasoning_efficiency - base_reasoning_efficiency, 6
        )

        # 构建任务详情
        task_details = {}
        for domain_name in ["general", "math", "code", "reasoning"]:
            if f"{domain_name}_tasks" in column_layout:
                task_scores = locals()[f"{domain_name}_task_scores"]
                if task_scores:
                    task_details[f"{domain_name}_tasks"] = self.organize_tasks_by_name(
                        column_layout[f"{domain_name}_tasks"],
                        column_layout[f"{domain_name}_metrics"],
                        task_scores,
                    )

        # 计算改进数据
        improvement = self._calculate_improvements(
            general_avg,
            math_avg,
            code_avg,
            reasoning_avg,
            overall_avg,
            general_efficiency_delta,
            math_efficiency_delta,
            code_efficiency_delta,
            reasoning_efficiency_delta,
            overall_efficiency_delta,
            general_task_scores,
            math_task_scores,
            code_task_scores,
            reasoning_task_scores,
            base_info,
            instruct_info,
        )

        # 创建数据集信息对象
        dataset_info = ModelInfo(
            id=dataset_id,
            name=dataset_name,
            domain=domain,
            general_avg=round(general_avg, 2),
            math_avg=round(math_avg, 2),
            code_avg=round(code_avg, 2),
            reasoning_avg=round(reasoning_avg, 2),
            overall_avg=round(overall_avg, 2),
            overall_efficiency=overall_efficiency_delta,
            general_efficiency=general_efficiency_delta,
            math_efficiency=math_efficiency_delta,
            code_efficiency=code_efficiency_delta,
            reasoning_efficiency=reasoning_efficiency_delta,
            general_task_scores=general_task_scores,
            math_task_scores=math_task_scores,
            code_task_scores=code_task_scores,
            reasoning_task_scores=reasoning_task_scores,
            task_details=task_details,
            improvement=improvement,
        )

        # 合并数据集属性
        dataset_info.affiliation = dataset_attr.get("affiliation", "")
        dataset_info.year = dataset_attr.get("year", "")
        dataset_info.size = dataset_attr.get("size", "")
        dataset_info.size_precise = dataset_attr.get("size_precise", "")
        dataset_info.link = dataset_attr.get("link", "")
        dataset_info.paper_link = dataset_attr.get("paper_link", "")
        dataset_info.scored_link = dataset_attr.get("scored_link", "")
        dataset_info.tag = dataset_attr.get("tag", "")

        if overall_avg > 0:
            self.logger.info(f"  ✅ 已添加: 综合 {overall_avg:.2f}")
            return dataset_info
        else:
            self.logger.info(f"  ❌ 跳过: 无有效数据")
            return None

    def _calculate_improvements(
        self,
        general_avg: float,
        math_avg: float,
        code_avg: float,
        reasoning_avg: float,
        overall_avg: float,
        general_efficiency: float,
        math_efficiency: float,
        code_efficiency: float,
        reasoning_efficiency: float,
        overall_efficiency: float,
        general_task_scores: List[Optional[float]],
        math_task_scores: List[Optional[float]],
        code_task_scores: List[Optional[float]],
        reasoning_task_scores: List[Optional[float]],
        base_info: ModelInfo,
        instruct_info: ModelInfo,
    ) -> Dict[str, Any]:
        """计算相对于基准模型的改进数据"""

        def safe_list_subtract(
            list1: List[Optional[float]], list2: List[float]
        ) -> List[float]:
            """安全地计算两个列表的差值"""
            result = []
            min_len = min(len(list1), len(list2))
            for i in range(min_len):
                if list1[i] is not None and list2[i] is not None:
                    result.append(round(list1[i] - list2[i], 2))
            return result

        # 相对于base模型的改进
        improvement_vs_base = {
            "general_avg": round(general_avg - base_info.general_avg, 2),
            "math_avg": round(math_avg - base_info.math_avg, 2),
            "code_avg": round(code_avg - base_info.code_avg, 2),
            "reasoning_avg": round(reasoning_avg - base_info.reasoning_avg, 2),
            "overall_avg": round(overall_avg - base_info.overall_avg, 2),
            "overall_efficiency": overall_efficiency,
            "general_efficiency": general_efficiency,
            "math_efficiency": math_efficiency,
            "code_efficiency": code_efficiency,
            "reasoning_efficiency": reasoning_efficiency,
            "general_task_scores": safe_list_subtract(
                general_task_scores, base_info.general_task_scores
            ),
            "math_task_scores": safe_list_subtract(
                math_task_scores, base_info.math_task_scores
            ),
            "code_task_scores": safe_list_subtract(
                code_task_scores, base_info.code_task_scores
            ),
            "reasoning_task_scores": safe_list_subtract(
                reasoning_task_scores, base_info.reasoning_task_scores
            ),
        }

        # 相对于instruct模型的改进
        improvement_vs_instruct = {
            "general_avg": round(general_avg - instruct_info.general_avg, 2),
            "math_avg": round(math_avg - instruct_info.math_avg, 2),
            "code_avg": round(code_avg - instruct_info.code_avg, 2),
            "reasoning_avg": round(reasoning_avg - instruct_info.reasoning_avg, 2),
            "overall_avg": round(overall_avg - instruct_info.overall_avg, 2),
            "overall_efficiency": 0,  # instruct模型无数据量信息
            "general_efficiency": 0,
            "math_efficiency": 0,
            "code_efficiency": 0,
            "reasoning_efficiency": 0,
            "general_task_scores": safe_list_subtract(
                general_task_scores, instruct_info.general_task_scores
            ),
            "math_task_scores": safe_list_subtract(
                math_task_scores, instruct_info.math_task_scores
            ),
            "code_task_scores": safe_list_subtract(
                code_task_scores, instruct_info.code_task_scores
            ),
            "reasoning_task_scores": safe_list_subtract(
                reasoning_task_scores, instruct_info.reasoning_task_scores
            ),
        }

        return {"vs_base": improvement_vs_base, "vs_instruct": improvement_vs_instruct}

    def process_sheet(self, sheet_name: str) -> List[ModelInfo]:
        """
        处理单个工作表

        Args:
            sheet_name: 工作表名称

        Returns:
            处理后的数据集列表
        """
        self.logger.info(f"\n--- 处理工作表: {sheet_name} ---")

        # 读取工作表数据
        df_raw = pd.read_excel(self.excel_file, sheet_name=sheet_name, header=None)
        # self.logger.info(f"工作表大小: {df_raw.shape}")

        # 检测列布局和领域分布
        column_layout = self.detect_column_layout(df_raw, sheet_name=sheet_name)
        domain_ranges = self.detect_domain_ranges(df_raw)

        # 处理base和instruct模型
        # NOTE(zzp): base, instruct
        base_row_idx = 3
        instruct_row_idx = 4

        base_row = df_raw.iloc[base_row_idx] if base_row_idx < len(df_raw) else None
        instruct_row = (
            df_raw.iloc[instruct_row_idx] if instruct_row_idx < len(df_raw) else None
        )

        if base_row is not None:
            self.logger.info(f"找到base行: 第{base_row_idx+1}行")
        else:
            self.logger.info("警告: 未找到base行")

        if instruct_row is not None:
            self.logger.info(f"找到instruct行: 第{instruct_row_idx+1}行")
        else:
            self.logger.info("警告: 未找到instruct行")

        # 创建base和instruct模型信息
        base_info = self.create_model_info(
            "base", sheet_name, base_row, column_layout, domain_ranges
        )
        instruct_info = self.create_model_info(
            "instruct", sheet_name, instruct_row, column_layout, domain_ranges
        )

        # 处理数据集
        datasets = []
        # NOTE(zzp): datasets start
        dataset_start_row = 5
        current_row = dataset_start_row

        while current_row < len(df_raw):
            dataset_name_cell = df_raw.iloc[current_row, 1]

            if pd.notna(dataset_name_cell):
                dataset_name = str(dataset_name_cell).strip()

                # 跳过表头或无效行
                if (
                    dataset_name.lower()
                    in [
                        "model",
                        "dataset",
                        "accuracy",
                        "general",
                        "math",
                        "code",
                        "reasoning",
                        "base",
                        "instruct",
                    ]
                    or len(dataset_name) == 0
                ):
                    current_row += 1
                    continue

                # 确定数据集领域
                dataset_domain = self.determine_dataset_domain(
                    current_row, domain_ranges
                )

                # 提取4行数据
                dataset_rows = []
                for i in range(4):
                    if current_row + i < len(df_raw):
                        dataset_rows.append(df_raw.iloc[current_row + i])

                # 处理数据集（使用预分配的ID）
                dataset_info = self.process_dataset(
                    dataset_name,
                    dataset_rows,
                    dataset_domain,
                    column_layout,
                    base_info,
                    instruct_info,
                )

                if dataset_info:
                    datasets.append(dataset_info)

                current_row += 4
            else:
                current_row += 1

        # 设置instruct和base模型的ID（固定为0和1）
        if instruct_info:
            instruct_info.id = 0
        if base_info:
            base_info.id = 1

        # 数据集ID已经在load_dataset_attributes中预分配，无需重新分配

        # 按正确顺序插入
        result = []
        if instruct_info:
            result.append(instruct_info)
        if base_info:
            result.append(base_info)
        result.extend(datasets)

        self.logger.info(f"\n{sheet_name} 工作表处理完成: {len(result)} 个数据集")
        return result

    def save_results(
        self, output_file: str = "llm_leaderboard.json"
    ) -> None:
        """保存处理结果到JSON文件"""
        with open(output_file, "w", encoding="utf-8") as f:
            json.dump(
                self.processed_data,
                f,
                ensure_ascii=False,
                indent=2,
                default=self._json_serializer,
            )
        self.logger.info(f"\n处理后的数据已保存到 {output_file}")

    def _json_serializer(self, obj):
        """JSON序列化器，处理dataclass对象"""
        if hasattr(obj, "__dict__"):
            return obj.__dict__
        raise TypeError(f"Object of type {type(obj)} is not JSON serializable")

    def print_statistics(self) -> None:
        """打印统计信息"""
        for sheet_name, data in self.processed_data.items():
            self.logger.info(f"\n{sheet_name} 示例数据 (前3个):")
            for i, item in enumerate(data[:3]):
                print(
                    f"{i+1}. {item.name} [{item.domain}]: 综合 {item.overall_avg} "
                    f"(性价比涨跌: {item.overall_efficiency:+.6f}), "
                    f"General {item.general_avg} (性价比: {item.general_efficiency:+.6f}), "
                    f"Math {item.math_avg} (性价比: {item.math_efficiency:+.6f}), "
                    f"Code {item.code_avg} (性价比: {item.code_efficiency:+.6f}), "
                    f"Reasoning {item.reasoning_avg} (性价比: {item.reasoning_efficiency:+.6f})"
                )

                if item.paper_link or item.scored_link or item.tag:
                    print(
                        f"    Paper Link: {item.paper_link if item.paper_link else '无'}"
                    )
                    print(
                        f"    Scored Link: {item.scored_link if item.scored_link else '无'}"
                    )
                    self.logger.info(f"    Tag: {item.tag if item.tag else '无'}")

            # 统计领域分布
            domain_count = {}
            for item in data:
                domain = item.domain
                domain_count[domain] = domain_count.get(domain, 0) + 1
            self.logger.info(f"  领域分布: {domain_count}")

    def process_all_sheets(
        self, sheets_to_process: List[str] = None
    ) -> Dict[str, List[ModelInfo]]:
        """
        处理所有工作表

        Args:
            sheets_to_process: 要处理的工作表列表

        Returns:
            处理后的数据字典
        """
        # NOTE(zzp): sheets
        if sheets_to_process is None:
            sheets_to_process = ["llama", "qwen", "qwen3"]

        # 加载数据集属性
        self.load_dataset_attributes()

        # 处理每个工作表
        for sheet_name in sheets_to_process:
            try:
                datasets = self.process_sheet(sheet_name)
                self.processed_data[sheet_name] = datasets
            except Exception as e:
                self.logger.info(f"处理工作表 {sheet_name} 时出错: {e}")
                import traceback

                traceback.print_exc()
                self.processed_data[sheet_name] = []

        return self.processed_data


def main():
    """主函数"""
    # 设置日志
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = f"excel_processing_{timestamp}.log"
    logger = setup_logging(log_file=log_file, log_level="INFO")

    logger.info("=" * 50)
    logger.info("开始处理Excel文件")
    logger.info(f"日志文件: {log_file}")
    logger.info("=" * 50)

    try:
        # 创建处理器实例
        processor = ExcelProcessor("llm_0228.xlsx", logger=logger)

        # 处理所有工作表
        processed_data = processor.process_all_sheets()

        # 保存结果
        processor.save_results()

        # 打印统计信息
        processor.print_statistics()

        logger.info("=" * 50)
        logger.info("处理完成！")
        logger.info(f"结果已保存到 llm_leaderboard.json")
        logger.info(f"详细日志已保存到 {log_file}")
        logger.info("=" * 50)

        return processed_data

    except Exception as e:
        logger.error(f"处理错误: {e}")
        import traceback

        logger.error(traceback.format_exc())
        return None


if __name__ == "__main__":
    main()
