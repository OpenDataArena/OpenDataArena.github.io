import json
import copy

def main():
    with open('llm_leaderboard.json', 'r', encoding='utf-8') as f:
        leaderboard_data = json.load(f)
    with open('llm_score.json', 'r', encoding='utf-8') as f:
        score_data = json.load(f)

    # 统一用小写name作为key
    score_data_map = {name.lower(): score_data[name] for name in score_data}

    merged_data = copy.deepcopy(leaderboard_data)

    for model_key in merged_data:
        for item in merged_data[model_key]:
            dataset_name = item.get('name')
            if dataset_name is None:
                # item['evaluation_score'] = None
                continue
            key = dataset_name.lower()
            if key in score_data_map:
                item['evaluation_score'] = score_data_map[key]
            else:
                # item['evaluation_score'] = None
                pass

    with open('llm.json', 'w', encoding='utf-8') as f:
        json.dump(merged_data, f, ensure_ascii=False, indent=2)

if __name__ == '__main__':
    main()