"""
OpenDataArena MM Excel数据处理模块

该模块用于处理Excel文件中的多模态模型性能数据，生成结构化的JSON数据用于排行榜显示。
主要功能包括：
1. 解析Excel文件中的数据集和模型信息
2. 计算各领域平均分数和性价比
3. 生成基准模型对比数据
4. 输出结构化的JSON数据

"""

import pandas as pd
import json
import numpy as np
import logging
import sys
from datetime import datetime
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass, field


def setup_logging(log_file: str = None, log_level: str = "INFO") -> logging.Logger:
    """
    设置日志配置

    Args:
        log_file: 日志文件路径，如果为None则只输出到控制台
        log_level: 日志级别 (DEBUG, INFO, WARNING, ERROR, CRITICAL)

    Returns:
        配置好的logger对象
    """
    # 创建logger
    logger = logging.getLogger("mm_excel_processor")
    logger.setLevel(getattr(logging, log_level.upper()))

    # 清除已有的处理器
    logger.handlers.clear()

    # 创建格式化器
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # 控制台处理器
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(getattr(logging, log_level.upper()))
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    # 文件处理器（如果指定了日志文件）
    if log_file:
        file_handler = logging.FileHandler(log_file, encoding="utf-8")
        file_handler.setLevel(getattr(logging, log_level.upper()))
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

    return logger


@dataclass
class TaskDetail:
    """任务详细信息数据类"""

    task_name: str
    metrics: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class ModelInfo:
    """模型信息数据类"""

    id: int
    name: str
    domain: str
    spatial_avg: float = 0.0
    reasoning_avg: float = 0.0
    general_avg: float = 0.0
    infographic_avg: float = 0.0
    overall_avg: float = 0.0
    overall_efficiency: float = 0.0
    spatial_efficiency: float = 0.0
    reasoning_efficiency: float = 0.0
    general_efficiency: float = 0.0
    infographic_efficiency: float = 0.0
    spatial_task_scores: List[float] = field(default_factory=list)
    reasoning_task_scores: List[float] = field(default_factory=list)
    general_task_scores: List[float] = field(default_factory=list)
    infographic_task_scores: List[float] = field(default_factory=list)
    task_details: Dict[str, List[TaskDetail]] = field(default_factory=dict)
    improvement: Dict[str, Any] = field(default_factory=dict)

    # 数据集属性
    affiliation: str = ""
    year: str = ""
    size: str = ""
    size_precise: str = ""
    link: str = ""
    paper_link: str = ""
    scored_link: str = ""
    tag: str = ""


class ExcelProcessor:
    """Excel数据处理器主类"""

    # 默认列配置（MM数据）
    DEFAULT_COLUMN_CONFIG = {
        "spatial_cols": list(range(3, 5)),  # D-E列
        "reasoning_cols": list(range(5, 12)),  # F-L列
        "general_cols": list(range(12, 18)),  # M-R列
        "infographic_cols": list(range(18, 22)),  # S-V列
    }

    # 领域关键词
    DOMAIN_KEYWORDS = ["spatial", "reasoning", "general", "infographic"]

    def __init__(self, excel_file: str = "mm_1202.xlsx", logger: logging.Logger = None):
        """
        初始化Excel处理器

        Args:
            excel_file: Excel文件路径
            logger: 日志记录器，如果为None则创建默认logger
        """
        self.excel_file = excel_file
        self.dataset_attr_map = {}
        self.processed_data = {}
        self.logger = logger or logging.getLogger("mm_excel_processor")

    def load_dataset_attributes(self) -> None:
        """加载数据集属性信息并分配固定编号"""
        self.logger.info("--- 加载数据集属性信息 ---")

        try:
            df_dataset = pd.read_excel(
                self.excel_file, sheet_name="datasets_info", header=None
            )

            # 从第2行开始提取数据集属性（第1行是表头）
            dataset_id = 2  # 从2开始分配ID（0和1预留给基准模型）

            for idx in range(1, len(df_dataset)):
                name = df_dataset.iloc[idx, 1] if idx < len(df_dataset) else None

                if pd.notna(name):
                    name_str = str(name).strip()

                    # 跳过表头行和无效名称
                    if (
                        name_str.lower()
                        in [
                            "none",
                            "dataset",
                            "affiliation",
                            "year",
                            "size",
                            "link",
                            "paper_link",
                            "scored_link",
                            "tag",
                        ]
                        or len(name_str) == 0
                    ):
                        continue

                    # 提取各种属性
                    # 列索引：0=空, 1=Dataset, 2=Affiliation, 3=Year, 4=Size, 5=Data Tag, 6=HF link, 7=Arxiv Link
                    attributes = {
                        "id": dataset_id,  # 分配固定ID
                        "affiliation": self._safe_get_cell(df_dataset, idx, 2),
                        "year": self._safe_get_cell(df_dataset, idx, 3),
                        "size": self._safe_get_cell(df_dataset, idx, 4),
                        "size_precise": self._safe_get_cell(df_dataset, idx, 4),  # MM数据中size和size_precise相同
                        "link": self._safe_get_cell(df_dataset, idx, 6),  # HF link
                        "paper_link": self._safe_get_cell(df_dataset, idx, 7),  # Arxiv Link
                        "scored_link": "",  # MM数据中没有scored_link
                        "tag": self._process_tags(self._safe_get_cell(df_dataset, idx, 5)),
                    }

                    self.dataset_attr_map[name_str] = attributes
                    dataset_id += 1  # 为下一个数据集分配ID

            self.logger.info(
                f"成功加载 {len(self.dataset_attr_map)} 个数据集属性，ID范围: 2-{dataset_id-1}"
            )

        except Exception as e:
            self.logger.error(f"加载数据集属性时出错: {e}")
            self.dataset_attr_map = {}

    def _safe_get_cell(self, df: pd.DataFrame, row: int, col: int) -> str:
        """安全获取单元格值"""
        if row < len(df) and col < len(df.columns):
            val = df.iloc[row, col]
            return str(val).strip() if pd.notna(val) else ""
        return ""

    def _process_tags(self, tag_str: str) -> str:
        """处理标签字符串"""
        if not tag_str or not str(tag_str).strip():
            return ""

        tags = [t.strip() for t in str(tag_str).strip().split(",") if t.strip()]
        return ",".join(tags)

    def detect_column_layout(self, df_raw: pd.DataFrame, sheet_name: str = None) -> Dict[str, Any]:
        """
        检测列布局和任务信息

        Args:
            df_raw: 原始数据DataFrame
            sheet_name: 工作表名称（用于获取特定的列配置）

        Returns:
            包含列配置和任务信息的字典
        """
        self.logger.info("\n--- 检测表头和列布局 ---")

        # 使用默认列配置
        config = self.DEFAULT_COLUMN_CONFIG.copy()
        self.logger.info("使用默认列配置:")
        for domain, cols in config.items():
            col_letters = [chr(65 + i) for i in cols]
            self.logger.info(
                f"  {domain.replace('_cols', '').upper()}: 列 {col_letters} (索引 {cols})"
            )

        # 提取任务信息（第1行是任务名称，第2行是指标名称）
        task_info = self._extract_task_info(df_raw, config)
        config.update(task_info)

        return config

    def _extract_task_info(
        self, df_raw: pd.DataFrame, column_config: Dict
    ) -> Dict[str, List[str]]:
        """提取任务名称和指标信息"""
        self.logger.info("\n--- 提取小任务信息 ---")

        task_info = {}

        if len(df_raw) > 2:
            task_name_row = df_raw.iloc[1]  # 第1行是任务名称
            metric_name_row = df_raw.iloc[2]  # 第2行是指标名称

            for domain in ["spatial", "reasoning", "general", "infographic"]:
                col_key = f"{domain}_cols"
                if col_key in column_config:
                    cols = column_config[col_key]

                    task_names, metric_names = self._extract_domain_tasks(
                        task_name_row, metric_name_row, cols, domain
                    )

                    task_info[f"{domain}_tasks"] = task_names
                    task_info[f"{domain}_metrics"] = metric_names

                    self.logger.info(f"  {domain.upper()}:")
                    for i, (task, metric) in enumerate(zip(task_names, metric_names)):
                        col_letter = chr(65 + cols[i]) if cols[i] < 26 else "?"
                        self.logger.info(f"    {col_letter}: {task} ({metric})")

        return task_info

    def _extract_domain_tasks(
        self, task_row: pd.Series, metric_row: pd.Series, cols: List[int], domain: str
    ) -> Tuple[List[str], List[str]]:
        """提取特定领域的任务和指标信息"""
        task_names = []
        metric_names = []

        for col_idx in cols:
            # 提取任务名称
            if col_idx < len(task_row):
                task_name = task_row.iloc[col_idx]
                if pd.notna(task_name) and str(task_name).strip():
                    task_names.append(str(task_name).strip())
                else:
                    task_names.append(f"Task_{col_idx}")
            else:
                task_names.append(f"Task_{col_idx}")

            # 提取指标名称
            if col_idx < len(metric_row):
                metric_name = metric_row.iloc[col_idx]
                if pd.notna(metric_name) and str(metric_name).strip():
                    metric_names.append(str(metric_name).strip())
                else:
                    metric_names.append("accuracy")
            else:
                metric_names.append("accuracy")

        return task_names, metric_names

    def extract_task_scores(
        self, row: pd.Series, col_indices: List[int]
    ) -> List[Optional[float]]:
        """
        为每个小任务提取分数（MM数据中每个数据集只有1行）

        Args:
            row: 数据行
            col_indices: 列索引列表

        Returns:
            任务分数列表，None表示无数据
        """
        task_scores = []

        for col_idx in col_indices:
            if col_idx < len(row):
                val = row.iloc[col_idx]
                if pd.notna(val):
                    try:
                        num_val = float(val)
                        task_scores.append(round(num_val, 2))
                    except (ValueError, TypeError):
                        task_scores.append(None)
                else:
                    task_scores.append(None)
            else:
                task_scores.append(None)

        return task_scores

    def extract_domain_scores(
        self, row: pd.Series, col_indices: List[int]
    ) -> List[float]:
        """从指定行和列提取有效数值"""
        scores = []
        for col_idx in col_indices:
            if col_idx < len(row):
                val = row.iloc[col_idx]
                if pd.notna(val):
                    try:
                        num_val = float(val)
                        scores.append(num_val)
                    except (ValueError, TypeError):
                        continue
        return scores

    def calculate_efficiency_score(
        self, avg_score: float, size_precise_str: str
    ) -> float:
        """
        计算数据性价比分数：平均分数 / 数据量 * 1000

        Args:
            avg_score: 平均分数
            size_precise_str: 数据量字符串

        Returns:
            性价比分数
        """
        if not size_precise_str or avg_score <= 0:
            return 0

        try:
            size_str = str(size_precise_str).strip().lower()

            # 处理常见的数字格式
            if "k" in size_str:
                size = float(size_str.replace("k", "").replace("K", "")) * 1000
            elif "m" in size_str:
                size = float(size_str.replace("m", "").replace("M", "")) * 1000000
            elif "b" in size_str:
                size = float(size_str.replace("b", "").replace("B", "")) * 1000000000
            else:
                size = float(size_str)

            if size > 0:
                efficiency = (avg_score / size) * 1000
                return round(efficiency, 6)
            else:
                return 0
        except (ValueError, TypeError):
            return 0

    def organize_tasks_by_name(
        self, tasks: List[str], metrics: List[str], scores: List[Optional[float]]
    ) -> List[TaskDetail]:
        """
        将相同任务名称的不同指标组织在一起

        Args:
            tasks: 任务名称列表
            metrics: 指标名称列表
            scores: 分数列表

        Returns:
            组织后的任务详情列表
        """
        organized_tasks = {}

        for task_name, metric_name, score in zip(tasks, metrics, scores):
            # 跳过无数据的任务
            if score is None:
                continue

            if task_name not in organized_tasks:
                organized_tasks[task_name] = TaskDetail(task_name=task_name)

            organized_tasks[task_name].metrics.append(
                {"metric": metric_name, "score": score}
            )

        return list(organized_tasks.values())

    def create_model_info(
        self,
        model_type: str,
        sheet_name: str,
        row: Optional[pd.Series],
        column_layout: Dict,
    ) -> ModelInfo:
        """
        创建模型信息对象

        Args:
            model_type: 模型类型 ('instruct' 或 'thinking')
            sheet_name: 工作表名称
            row: 数据行
            column_layout: 列布局配置

        Returns:
            模型信息对象
        """
        # 设置模型名称
        if model_type == "instruct":
            name = "Qwen3-VL-8B-Instruct"
            model_id = 0
        elif model_type == "thinking":
            name = "Qwen3-VL-8B-Thinking"
            model_id = 1
        else:
            name = model_type
            model_id = 1

        if row is None:
            # 创建空模型信息
            return ModelInfo(id=model_id, name=name, domain=model_type, task_details={})

        # 提取各领域分数
        spatial_cols = column_layout["spatial_cols"]
        reasoning_cols = column_layout["reasoning_cols"]
        general_cols = column_layout["general_cols"]
        infographic_cols = column_layout["infographic_cols"]

        spatial_task_scores = self._extract_base_task_scores(row, spatial_cols)
        reasoning_task_scores = self._extract_base_task_scores(row, reasoning_cols)
        general_task_scores = self._extract_base_task_scores(row, general_cols)
        infographic_task_scores = self._extract_base_task_scores(row, infographic_cols)

        # 计算平均分
        spatial_avg = np.mean(spatial_task_scores) if spatial_task_scores else 0
        reasoning_avg = np.mean(reasoning_task_scores) if reasoning_task_scores else 0
        general_avg = np.mean(general_task_scores) if general_task_scores else 0
        infographic_avg = (
            np.mean(infographic_task_scores) if infographic_task_scores else 0
        )

        valid_averages = [
            avg
            for avg in [spatial_avg, reasoning_avg, general_avg, infographic_avg]
            if avg > 0
        ]
        overall_avg = np.mean(valid_averages) if valid_averages else 0

        self.logger.info(
            f"{model_type.capitalize()}行分数 - Spatial: {spatial_avg:.2f}, Reasoning: {reasoning_avg:.2f}, "
            f"General: {general_avg:.2f}, Infographic: {infographic_avg:.2f}, Overall: {overall_avg:.2f}"
        )

        # 构建任务详情
        task_details = {}
        for domain in ["spatial", "reasoning", "general", "infographic"]:
            if f"{domain}_tasks" in column_layout:
                task_scores = locals()[f"{domain}_task_scores"]
                if task_scores:
                    task_details[f"{domain}_tasks"] = self.organize_tasks_by_name(
                        column_layout[f"{domain}_tasks"],
                        column_layout[f"{domain}_metrics"],
                        task_scores,
                    )

        return ModelInfo(
            id=model_id,
            name=name,
            domain=model_type,
            spatial_avg=round(spatial_avg, 2),
            reasoning_avg=round(reasoning_avg, 2),
            general_avg=round(general_avg, 2),
            infographic_avg=round(infographic_avg, 2),
            overall_avg=round(overall_avg, 2),
            spatial_task_scores=spatial_task_scores,
            reasoning_task_scores=reasoning_task_scores,
            general_task_scores=general_task_scores,
            infographic_task_scores=infographic_task_scores,
            task_details=task_details,
        )

    def _extract_base_task_scores(
        self, row: pd.Series, col_indices: List[int]
    ) -> List[float]:
        """从基准模型行提取各列的分数，值为0参与计算，空值不参与计算"""
        task_scores = []
        for col_idx in col_indices:
            if col_idx < len(row):
                val = row.iloc[col_idx]
                if pd.notna(val):
                    try:
                        task_scores.append(float(val))
                    except (ValueError, TypeError):
                        pass
        return task_scores

    def process_dataset(
        self,
        dataset_name: str,
        dataset_row: pd.Series,
        column_layout: Dict,
        instruct_info: ModelInfo,
        thinking_info: ModelInfo,
    ) -> Optional[ModelInfo]:
        """
        处理单个数据集

        Args:
            dataset_name: 数据集名称
            dataset_row: 数据集行数据（MM数据中每个数据集只有1行）
            column_layout: 列布局配置
            instruct_info: 基准模型信息（Qwen3-VL-8B-Instruct）
            thinking_info: 基准模型信息（Qwen3-VL-8B-Thinking）

        Returns:
            处理后的数据集信息对象
        """
        self.logger.info(f"\n处理数据集: {dataset_name}")

        # 从预分配的属性中获取ID
        dataset_attr = self.dataset_attr_map.get(dataset_name, {})
        dataset_id = dataset_attr.get("id", 999)  # 如果找不到，使用999作为默认ID

        # 提取各领域分数
        spatial_cols = column_layout["spatial_cols"]
        reasoning_cols = column_layout["reasoning_cols"]
        general_cols = column_layout["general_cols"]
        infographic_cols = column_layout["infographic_cols"]

        spatial_scores = self.extract_domain_scores(dataset_row, spatial_cols)
        reasoning_scores = self.extract_domain_scores(dataset_row, reasoning_cols)
        general_scores = self.extract_domain_scores(dataset_row, general_cols)
        infographic_scores = self.extract_domain_scores(dataset_row, infographic_cols)

        spatial_task_scores = self.extract_task_scores(dataset_row, spatial_cols)
        reasoning_task_scores = self.extract_task_scores(dataset_row, reasoning_cols)
        general_task_scores = self.extract_task_scores(dataset_row, general_cols)
        infographic_task_scores = self.extract_task_scores(
            dataset_row, infographic_cols
        )

        self.logger.info(
            f"  Spatial: {len(spatial_scores)} 个有效数据, {len([s for s in spatial_task_scores if s is not None])} 个任务"
        )
        self.logger.info(
            f"  Reasoning: {len(reasoning_scores)} 个有效数据, {len([s for s in reasoning_task_scores if s is not None])} 个任务"
        )
        self.logger.info(
            f"  General: {len(general_scores)} 个有效数据, {len([s for s in general_task_scores if s is not None])} 个任务"
        )
        self.logger.info(
            f"  Infographic: {len(infographic_scores)} 个有效数据, {len([s for s in infographic_task_scores if s is not None])} 个任务"
        )

        # 计算平均分
        spatial_avg = np.mean(spatial_scores) if spatial_scores else 0
        reasoning_avg = np.mean(reasoning_scores) if reasoning_scores else 0
        general_avg = np.mean(general_scores) if general_scores else 0
        infographic_avg = np.mean(infographic_scores) if infographic_scores else 0

        valid_averages = [
            avg
            for avg in [spatial_avg, reasoning_avg, general_avg, infographic_avg]
            if avg > 0
        ]
        overall_avg = np.mean(valid_averages) if valid_averages else 0

        # 计算性价比分数
        dataset_attr = self.dataset_attr_map.get(dataset_name, {})
        size_precise = dataset_attr.get("size_precise", "")

        overall_efficiency = self.calculate_efficiency_score(overall_avg, size_precise)
        spatial_efficiency = self.calculate_efficiency_score(spatial_avg, size_precise)
        reasoning_efficiency = self.calculate_efficiency_score(
            reasoning_avg, size_precise
        )
        general_efficiency = self.calculate_efficiency_score(general_avg, size_precise)
        infographic_efficiency = self.calculate_efficiency_score(
            infographic_avg, size_precise
        )

        # 计算相对于instruct模型的性价比涨跌（使用instruct作为基准）
        instruct_overall_efficiency = self.calculate_efficiency_score(
            instruct_info.overall_avg, size_precise
        )
        instruct_spatial_efficiency = self.calculate_efficiency_score(
            instruct_info.spatial_avg, size_precise
        )
        instruct_reasoning_efficiency = self.calculate_efficiency_score(
            instruct_info.reasoning_avg, size_precise
        )
        instruct_general_efficiency = self.calculate_efficiency_score(
            instruct_info.general_avg, size_precise
        )
        instruct_infographic_efficiency = self.calculate_efficiency_score(
            instruct_info.infographic_avg, size_precise
        )

        overall_efficiency_delta = round(
            overall_efficiency - instruct_overall_efficiency, 6
        )
        spatial_efficiency_delta = round(
            spatial_efficiency - instruct_spatial_efficiency, 6
        )
        reasoning_efficiency_delta = round(
            reasoning_efficiency - instruct_reasoning_efficiency, 6
        )
        general_efficiency_delta = round(
            general_efficiency - instruct_general_efficiency, 6
        )
        infographic_efficiency_delta = round(
            infographic_efficiency - instruct_infographic_efficiency, 6
        )

        # 构建任务详情
        task_details = {}
        for domain_name in ["spatial", "reasoning", "general", "infographic"]:
            if f"{domain_name}_tasks" in column_layout:
                task_scores = locals()[f"{domain_name}_task_scores"]
                if task_scores:
                    task_details[f"{domain_name}_tasks"] = self.organize_tasks_by_name(
                        column_layout[f"{domain_name}_tasks"],
                        column_layout[f"{domain_name}_metrics"],
                        task_scores,
                    )

        # 计算改进数据
        improvement = self._calculate_improvements(
            spatial_avg,
            reasoning_avg,
            general_avg,
            infographic_avg,
            overall_avg,
            spatial_efficiency_delta,
            reasoning_efficiency_delta,
            general_efficiency_delta,
            infographic_efficiency_delta,
            overall_efficiency_delta,
            spatial_task_scores,
            reasoning_task_scores,
            general_task_scores,
            infographic_task_scores,
            instruct_info,
            thinking_info,
        )

        # 创建数据集信息对象
        dataset_info = ModelInfo(
            id=dataset_id,
            name=dataset_name,
            domain="dataset",  # MM数据中不区分领域，统一标记为dataset
            spatial_avg=round(spatial_avg, 2),
            reasoning_avg=round(reasoning_avg, 2),
            general_avg=round(general_avg, 2),
            infographic_avg=round(infographic_avg, 2),
            overall_avg=round(overall_avg, 2),
            overall_efficiency=overall_efficiency_delta,
            spatial_efficiency=spatial_efficiency_delta,
            reasoning_efficiency=reasoning_efficiency_delta,
            general_efficiency=general_efficiency_delta,
            infographic_efficiency=infographic_efficiency_delta,
            spatial_task_scores=spatial_task_scores,
            reasoning_task_scores=reasoning_task_scores,
            general_task_scores=general_task_scores,
            infographic_task_scores=infographic_task_scores,
            task_details=task_details,
            improvement=improvement,
        )

        # 合并数据集属性
        dataset_info.affiliation = dataset_attr.get("affiliation", "")
        dataset_info.year = dataset_attr.get("year", "")
        dataset_info.size = dataset_attr.get("size", "")
        dataset_info.size_precise = dataset_attr.get("size_precise", "")
        dataset_info.link = dataset_attr.get("link", "")
        dataset_info.paper_link = dataset_attr.get("paper_link", "")
        dataset_info.scored_link = dataset_attr.get("scored_link", "")
        dataset_info.tag = dataset_attr.get("tag", "")

        if overall_avg > 0:
            self.logger.info(f"  ✅ 已添加: 综合 {overall_avg:.2f}")
            return dataset_info
        else:
            self.logger.info(f"  ❌ 跳过: 无有效数据")
            return None

    def _calculate_improvements(
        self,
        spatial_avg: float,
        reasoning_avg: float,
        general_avg: float,
        infographic_avg: float,
        overall_avg: float,
        spatial_efficiency: float,
        reasoning_efficiency: float,
        general_efficiency: float,
        infographic_efficiency: float,
        overall_efficiency: float,
        spatial_task_scores: List[Optional[float]],
        reasoning_task_scores: List[Optional[float]],
        general_task_scores: List[Optional[float]],
        infographic_task_scores: List[Optional[float]],
        instruct_info: ModelInfo,
        thinking_info: ModelInfo,
    ) -> Dict[str, Any]:
        """计算相对于基准模型的改进数据"""

        def safe_list_subtract(
            list1: List[Optional[float]], list2: List[float]
        ) -> List[float]:
            """安全地计算两个列表的差值"""
            result = []
            min_len = min(len(list1), len(list2))
            for i in range(min_len):
                if list1[i] is not None and list2[i] is not None:
                    result.append(round(list1[i] - list2[i], 2))
            return result

        # 相对于instruct模型的改进
        improvement_vs_instruct = {
            "spatial_avg": round(spatial_avg - instruct_info.spatial_avg, 2),
            "reasoning_avg": round(reasoning_avg - instruct_info.reasoning_avg, 2),
            "general_avg": round(general_avg - instruct_info.general_avg, 2),
            "infographic_avg": round(
                infographic_avg - instruct_info.infographic_avg, 2
            ),
            "overall_avg": round(overall_avg - instruct_info.overall_avg, 2),
            "overall_efficiency": overall_efficiency,
            "spatial_efficiency": spatial_efficiency,
            "reasoning_efficiency": reasoning_efficiency,
            "general_efficiency": general_efficiency,
            "infographic_efficiency": infographic_efficiency,
            "spatial_task_scores": safe_list_subtract(
                spatial_task_scores, instruct_info.spatial_task_scores
            ),
            "reasoning_task_scores": safe_list_subtract(
                reasoning_task_scores, instruct_info.reasoning_task_scores
            ),
            "general_task_scores": safe_list_subtract(
                general_task_scores, instruct_info.general_task_scores
            ),
            "infographic_task_scores": safe_list_subtract(
                infographic_task_scores, instruct_info.infographic_task_scores
            ),
        }

        # 相对于thinking模型的改进
        improvement_vs_thinking = {
            "spatial_avg": round(spatial_avg - thinking_info.spatial_avg, 2),
            "reasoning_avg": round(reasoning_avg - thinking_info.reasoning_avg, 2),
            "general_avg": round(general_avg - thinking_info.general_avg, 2),
            "infographic_avg": round(
                infographic_avg - thinking_info.infographic_avg, 2
            ),
            "overall_avg": round(overall_avg - thinking_info.overall_avg, 2),
            "overall_efficiency": 0,  # thinking模型无数据量信息
            "spatial_efficiency": 0,
            "reasoning_efficiency": 0,
            "general_efficiency": 0,
            "infographic_efficiency": 0,
            "spatial_task_scores": safe_list_subtract(
                spatial_task_scores, thinking_info.spatial_task_scores
            ),
            "reasoning_task_scores": safe_list_subtract(
                reasoning_task_scores, thinking_info.reasoning_task_scores
            ),
            "general_task_scores": safe_list_subtract(
                general_task_scores, thinking_info.general_task_scores
            ),
            "infographic_task_scores": safe_list_subtract(
                infographic_task_scores, thinking_info.infographic_task_scores
            ),
        }

        return {
            "vs_instruct": improvement_vs_instruct,
            "vs_thinking": improvement_vs_thinking,
        }

    def process_sheet(self, sheet_name: str) -> List[ModelInfo]:
        """
        处理单个工作表

        Args:
            sheet_name: 工作表名称

        Returns:
            处理后的数据集列表
        """
        self.logger.info(f"\n--- 处理工作表: {sheet_name} ---")

        # 读取工作表数据
        df_raw = pd.read_excel(self.excel_file, sheet_name=sheet_name, header=None)

        # 检测列布局
        column_layout = self.detect_column_layout(df_raw, sheet_name=sheet_name)

        # 处理基准模型（第3行是instruct，第4行是thinking）
        instruct_row_idx = 3
        thinking_row_idx = 4

        instruct_row = (
            df_raw.iloc[instruct_row_idx] if instruct_row_idx < len(df_raw) else None
        )
        thinking_row = (
            df_raw.iloc[thinking_row_idx] if thinking_row_idx < len(df_raw) else None
        )

        if instruct_row is not None:
            self.logger.info(f"找到instruct行: 第{instruct_row_idx+1}行")
        else:
            self.logger.info("警告: 未找到instruct行")

        if thinking_row is not None:
            self.logger.info(f"找到thinking行: 第{thinking_row_idx+1}行")
        else:
            self.logger.info("警告: 未找到thinking行")

        # 创建基准模型信息
        instruct_info = self.create_model_info(
            "instruct", sheet_name, instruct_row, column_layout
        )
        thinking_info = self.create_model_info(
            "thinking", sheet_name, thinking_row, column_layout
        )

        # 处理数据集（从第5行开始，每个数据集只有1行）
        datasets = []
        dataset_start_row = 5
        current_row = dataset_start_row

        while current_row < len(df_raw):
            dataset_name_cell = df_raw.iloc[current_row, 1]

            if pd.notna(dataset_name_cell):
                dataset_name = str(dataset_name_cell).strip()

                # 跳过表头或无效行
                if (
                    dataset_name.lower()
                    in [
                        "model",
                        "dataset",
                        "accuracy",
                        "spatial",
                        "reasoning",
                        "general",
                        "infographic",
                        "instruct",
                        "thinking",
                    ]
                    or len(dataset_name) == 0
                ):
                    current_row += 1
                    continue

                # 提取数据集行（MM数据中每个数据集只有1行）
                dataset_row = df_raw.iloc[current_row]

                # 处理数据集
                dataset_info = self.process_dataset(
                    dataset_name,
                    dataset_row,
                    column_layout,
                    instruct_info,
                    thinking_info,
                )

                if dataset_info:
                    datasets.append(dataset_info)

                current_row += 1
            else:
                current_row += 1

        # 设置基准模型的ID（固定为0和1）
        if instruct_info:
            instruct_info.id = 0
        if thinking_info:
            thinking_info.id = 1

        # 按正确顺序插入
        result = []
        if instruct_info:
            result.append(instruct_info)
        if thinking_info:
            result.append(thinking_info)
        result.extend(datasets)

        self.logger.info(f"\n{sheet_name} 工作表处理完成: {len(result)} 个数据集")
        return result

    def save_results(self, output_file: str = "mm_leaderboard.json") -> None:
        """保存处理结果到JSON文件"""
        with open(output_file, "w", encoding="utf-8") as f:
            json.dump(
                self.processed_data,
                f,
                ensure_ascii=False,
                indent=2,
                default=self._json_serializer,
            )
        self.logger.info(f"\n处理后的数据已保存到 {output_file}")

    def _json_serializer(self, obj):
        """JSON序列化器，处理dataclass对象"""
        if hasattr(obj, "__dict__"):
            return obj.__dict__
        raise TypeError(f"Object of type {type(obj)} is not JSON serializable")

    def print_statistics(self) -> None:
        """打印统计信息"""
        for sheet_name, data in self.processed_data.items():
            self.logger.info(f"\n{sheet_name} 示例数据 (前3个):")
            for i, item in enumerate(data[:3]):
                print(
                    f"{i+1}. {item.name} [{item.domain}]: 综合 {item.overall_avg} "
                    f"(性价比涨跌: {item.overall_efficiency:+.6f}), "
                    f"Spatial {item.spatial_avg} (性价比: {item.spatial_efficiency:+.6f}), "
                    f"Reasoning {item.reasoning_avg} (性价比: {item.reasoning_efficiency:+.6f}), "
                    f"General {item.general_avg} (性价比: {item.general_efficiency:+.6f}), "
                    f"Infographic {item.infographic_avg} (性价比: {item.infographic_efficiency:+.6f})"
                )

                if item.paper_link or item.link or item.tag:
                    print(
                        f"    Paper Link: {item.paper_link if item.paper_link else '无'}"
                    )
                    print(f"    HF Link: {item.link if item.link else '无'}")
                    self.logger.info(f"    Tag: {item.tag if item.tag else '无'}")

            # 统计领域分布
            domain_count = {}
            for item in data:
                domain = item.domain
                domain_count[domain] = domain_count.get(domain, 0) + 1
            self.logger.info(f"  领域分布: {domain_count}")

    def process_all_sheets(self, sheets_to_process: List[str] = None) -> Dict[str, List[ModelInfo]]:
        """
        处理所有工作表

        Args:
            sheets_to_process: 要处理的工作表列表

        Returns:
            处理后的数据字典
        """
        if sheets_to_process is None:
            sheets_to_process = ["qwen3vl"]

        # 加载数据集属性
        self.load_dataset_attributes()

        # 处理每个工作表
        for sheet_name in sheets_to_process:
            try:
                datasets = self.process_sheet(sheet_name)
                self.processed_data[sheet_name] = datasets
            except Exception as e:
                self.logger.info(f"处理工作表 {sheet_name} 时出错: {e}")
                import traceback

                traceback.print_exc()
                self.processed_data[sheet_name] = []

        return self.processed_data


def main():
    """主函数"""
    # 设置日志
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = f"mm_excel_processing_{timestamp}.log"
    logger = setup_logging(log_file=log_file, log_level="INFO")

    logger.info("=" * 50)
    logger.info("开始处理MM Excel文件")
    logger.info(f"日志文件: {log_file}")
    logger.info("=" * 50)

    try:
        # 创建处理器实例
        processor = ExcelProcessor("mm_0121.xlsx", logger=logger)

        # 处理所有工作表
        processed_data = processor.process_all_sheets()

        # 保存结果
        processor.save_results()

        # 打印统计信息
        processor.print_statistics()

        logger.info("=" * 50)
        logger.info("处理完成！")
        logger.info(f"结果已保存到 mm_leaderboard.json")
        logger.info(f"详细日志已保存到 {log_file}")
        logger.info("=" * 50)

        return processed_data

    except Exception as e:
        logger.error(f"处理错误: {e}")
        import traceback

        logger.error(traceback.format_exc())
        return None


if __name__ == "__main__":
    main()

