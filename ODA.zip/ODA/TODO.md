# data-lineage 功能修复方案

## 问题

`data-lineage/website/index.html` 是一个依赖 Flask 后端的全栈应用。当前作为子页面嵌入主站后，所有 API 请求都发往 GitHub Pages（纯静态），因此全部失败，导致页面功能不可用。

涉及的 API 端点：
- `/api/lineage/bootstrap` — 加载初始图谱数据
- `/api/lineage/query` — 动态查询数据集血缘
- `/api/health` — 检测后端是否可用（控制 LLM 摘要按钮显隐）
- `/api/summarize-sources` — 调用 LLM 生成数据集摘要

## 修改计划

### 1. 部署 api_server.py 到服务器

在一台服务器上运行 Flask 后端，提供 API 服务。

```bash
# 配置环境变量
export OPENAI_API_KEY="your-key"
export OPENAI_BASE_URL="your-url"
export OPENAI_MODEL="your-model"

# 启动（默认 0.0.0.0:8004）
cd data-lineage/website
./start_server.sh
```

确认服务器地址，例如 `https://your-server:8004`。

### 2. 修改 data-lineage/website/index.html — API 地址可配置化

在 `<script>` 标签开头（约第 4229 行之前）加入 API_BASE 配置：

```js
const API_BASE = window.LINEAGE_API_BASE || '';
```

然后修改两个常量定义（第 4229-4230 行）：

```js
// 旧：
const LINEAGE_API_ENDPOINT = '/api/lineage/query';
const LINEAGE_BOOTSTRAP_ENDPOINT = '/api/lineage/bootstrap';

// 新：
const LINEAGE_API_ENDPOINT = API_BASE + '/api/lineage/query';
const LINEAGE_BOOTSTRAP_ENDPOINT = API_BASE + '/api/lineage/bootstrap';
```

修改首页背景动画的 bootstrap 请求（第 5334 行）：

```js
// 旧：
fetch('/api/lineage/bootstrap?modality=text')

// 新：
fetch(API_BASE + '/api/lineage/bootstrap?modality=text')
```

修改健康检查（第 8847 行）：

```js
// 旧：
const response = await fetch('/api/health', {

// 新：
const response = await fetch(API_BASE + '/api/health', {
```

修改 LLM 摘要请求（第 8948 行）：

```js
// 旧：
const response = await fetch('/api/summarize-sources', {

// 新：
const response = await fetch(API_BASE + '/api/summarize-sources', {
```

### 3. 注入 API_BASE 配置

在 `data-lineage/website/index.html` 的 `<head>` 中（D3 script 标签之前）加入：

```html
<script>window.LINEAGE_API_BASE = 'https://your-server:8004';</script>
```

部署时替换为实际的服务器地址。本地开发时设为空字符串或 `http://localhost:8004`。

### 4. 复制静态回退文件

当 API 不可用时，页面有回退逻辑（第 5917-5918 行）会尝试加载 `graph.jsonl` 和 `data.jsonl`，但这两个文件在 `data-lineage/website/` 下不存在。

```bash
cp data-lineage/output/text-only_modality/graph.jsonl data-lineage/website/graph.jsonl
cp data-lineage/output/text-only_modality/data.jsonl data-lineage/website/data.jsonl
```

这样即使后端暂时不可达，页面也能展示已有数据（只读模式）。

## 修改清单

- [ ] 服务器部署 `api_server.py`，确认可访问地址
- [ ] `data-lineage/website/index.html`：加入 `API_BASE` 变量，6 处 API 路径加前缀
- [ ] `data-lineage/website/index.html`：`<head>` 中注入实际的 `LINEAGE_API_BASE` 地址
- [ ] 复制 `graph.jsonl` 和 `data.jsonl` 到 `data-lineage/website/` 作为静态回退
